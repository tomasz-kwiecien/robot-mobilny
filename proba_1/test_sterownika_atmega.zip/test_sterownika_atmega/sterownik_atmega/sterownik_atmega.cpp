//wyb�r programu do kompilacji              //pami�� dane komentarz
//#include "01_wyswietlanie_panelem.h"		//1516 110 dokumentacja b��d�w fatalnych
//#include "02_test_makr.h"					//368 98 dokumentacja b��d�w fatalnych
//#include "03_wyswietlanie_panelem.h"      //1532 110 dzia�a
//#include "04_wswietlanie_kilku_znakow.h"  //3358 244 dokumentacja b��d�w drobnych, poz��czany kod
//#include "05_sterowniki_a4988.h"
//#include "06_sterowniki_a4998_wiecej_taktowan.h"
#include "07_uproszczenie_timing.h"

/*
ascii7seg.h			b��dna wersja 1.1
ports.h				poprawiona wersja 1.1
char7seg			poprawiona wersja 1.2 pliku ascii7seg
nie istnieje standard znak�w na panel 7 segmentowy
wiki:Seven-segment display character representations
wi�c nie ma sensu pisa� American Standard ... co� tam  (je�eli ju� to asciic a nie cascii)
mo�na napisa� char7seg ewentualnie, bo wy�wietlaczem wcale nie musi by� led
mo�e by� nixie tube, mog� by� �ar�wki, mo�e by� lcd, mog� by� jarzeni�wki,
i jeszcze z kilka innych technik jakie widzia�em na youtube (silniczki, i jeszcze co� innego)
wi�c zmieni�em nazw� led7seg na char7seg
*/
