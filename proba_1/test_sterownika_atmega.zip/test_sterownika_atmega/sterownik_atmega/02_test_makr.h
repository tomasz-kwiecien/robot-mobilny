
/* 01_wyswietlanie_panelem

SPRZ�T:

lpt1, severino, m8 #1, 16000000mhz
atmega8 ma porty 6,6,8 bitowe: B 0-5, C 0-5, D 0-7
�wiate�ko kontrolne jest na B5, sz�stym bicie portu B

panel led podpi�cy z opornikami 1,5k, zapalane stanem niskim
podpi�cie kabla od panelu: aC0 fC1 bB5 gB4 cB3 eB2 hB1 dB0, h-decimal point
h u�yte jako kontrolka

ROZWA�ANIA:

potrzebny jest kabelek wpi�ty do p�ytki, �eby nie wpina� ci�gle kabla programatora do p�ytki
oraz pakiet przeka�nik�w na 8 linii, programowany zworkami, 6 linii programatora, 2 linie zasilania
z pze��cznikiem i dwiema diodami sygnalizuj�cymi, zielony-zasilanie, czerwony-programowanie
�eby sygna�em wizualnym nie by� tylko kolor, ale tak�e zmiana po�o�enia �wiec�cego punktu

WYNIKI:

zapalaj� si� tylko segmenty ab, ale wydaje si� �e prawid�owo
dalej mia�em ! zamiast ~
maski test�w bitowych by�y szesnastkowe zamiast binarne, 0x00000001 zamiast 0b00000001

*/

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>
#include "ports.h"

//#include "ascii7seg.h" 
// ver 1.1
//========================

const char a7s_led[]={
	0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,
	63,6,91,79,102,109,125,7,
	127,111,0,0,0,0,0,0,

	0,119,79,57,15,121,113,61,
	118,48,14,122,56,43,55,63,
	115,103,117,109,49,62,30,29,
	54,110,91,0,0,0,0,0,

	0,95,124,88,94,89,81,101,
	116,16,12,112,24,82,84,92,
	51,71,80,101,120,28,20,42,
	18,106,82,0,0,0,0,0
};

#define CHECK_AND_SET(byte,mask,port,pin) if (byte & mask) PORT##port |= (1<<pin); else PORT##port &= ~(1<<pin);

#define A7S_LED_OUT_BITS(bit_code, ao,ai, bo,bi, co,ci, do,di, eo,ei, fo,fi, go,gi, ho,hi) \
	CHECK_AND_SET(bit_code,0b00000001,ao,ai) \
	CHECK_AND_SET(bit_code,0b00000010,bo,bi) \
	CHECK_AND_SET(bit_code,0b00000100,co,ci) \
	CHECK_AND_SET(bit_code,0b00001000,do,di) \
	CHECK_AND_SET(bit_code,0b00010000,eo,ei) \
	CHECK_AND_SET(bit_code,0b00100000,fo,fi) \
	CHECK_AND_SET(bit_code,0b01000000,go,gi) \
	CHECK_AND_SET(bit_code,0b10000000,ho,hi) 

//==========================


// podpi�cie kabla od panelu: aC0 fC1 bB5 gB4 cB3 eB2 hB1 dB0, wsp�lna anoda
// konfiguracja makra: a-C0 b-B5 c-B3 d-B0 e-B2 f-C1 g-B4 h-B1
int A7S_BUFFER;  // zmienna dla drobnego przyspieszenia dzia�ania
#define LED_OUT(char_code) \
	A7S_BUFFER = ~ a7s_led [char_code-32]; \
	A7S_LED_OUT_BITS(A7S_BUFFER, C,0, B,5, B,3, B,0, B,2, C,1, B,4, B,1)

int main(void)
{
	DDRB=0xff;
	DDRC=0xff;
	OUT_INIT_PORT(C)
	
	while(1)
	{
		for (char c='0'; c<='9'; c++)
		{
			LED_OUT(c);
			_delay_ms(200);
		}
	}
}
