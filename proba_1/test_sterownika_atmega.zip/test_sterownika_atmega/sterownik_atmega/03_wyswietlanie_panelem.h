
/* 01_wyswietlanie_panelem

SPRZ�T:

lpt1, severino, m8 #1, 16000000mhz

FRAME_06, silnik lewy D7654, silnik prawy D3210
ULN na p�ytce stykowej, GND i 9V (12V) wzi�te z pin�w p�ytki
zasilanie z akumulatora wpi�te do gniazda p�ytki

Przyciski na C3-P1 C4-P2 C5-P3, lewo, naprz�d, prawo
P1+P3 wstecz, P2+P3 taktowanie szybsze o 5+2, P1+P2 taktowanie wolniejsze o 5+2

pocz�tkowe taktowanie 50+20

panel led podpi�cy z opornikami 1,5k, zapalane stanem niskim
podpi�cie kabla od panelu: aC0 fC1 bB5 gB4 cB3 eB2 hB1 dB0, h-decimal point
h u�yte jako kontrolka

WYNIKI :
czasami mia�em w��czone programator i zasilanie
zmieni�em op�nienie P1+P2 i P2+P3 z 500 na 150
zmieni�em cyfr� wy�wietlan� tak �eby odpowiada�a szybko�ci ruchu a nie okresowi taktowania

Program Memory Usage: 1510 bytes 18,4 % Full
Data Memory Usage:     110 bytes 10,7 % Full

jak akumulator 380g nie le�y symetrycznie, to zwi�kszony nacisk na lewe k�ko
powoduje zacinanie si� przy skr�cie w lewo, bo lewy silnik jest s�abszy
a zwi�kszony nacisk na prawe k�ko jeszcze nie powoduje zacinania

teraz chc� zrobi� na odzielnej wymiennej ma�ej p�ytce stykowej,
z tak samo rozmieszczonymi gniazdami zasilania wej�cia i wyj�cia :
L297 - stepper driver
A4988 - stepper driver - Pololu item #: 2128

*/

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>
#include "ports.h"
#include "char7seg.h"

//podpi�cie kabla od panelu: aC0 fC1 bB5 gB4 cB3 eB2 hB1 dB0, wsp�lna anoda
//konfiguracja makra: a-C0 b-B5 c-B3 d-B0 e-B2 f-C1 g-B4 h-B1
int BUFFER;  // zmienna dla drobnego przyspieszenia dzia�ania
#define LED_OUT(char_code) \
	BUFFER = ~ ASCII7SEG [char_code-32]; \
	LED_OUT_BITS(BUFFER, C,0, B,5, B,3, B,0, B,2, C,1, B,4, B,1)

static unsigned char wavedrive_lo_byte[4]={
	0b00000001,
	0b00000010,
	0b00000100,
	0b00001000
};

static unsigned char wavedrive_hi_byte[4]={
	0b00010000,
	0b00100000,
	0b01000000,
	0b10000000
};

#define FWD(p) p = (p+1)%4;
#define BCK(p) p = (p+3)%4;

// wiele taktowa�

#define INC_MOD(n,m) n=(n+1)%m;
#define DEC_MOD(n,m) n=(n+m-1)%m;

// _delay_ms oczekuje sta�ej jako argumentu  ( __builtin_avr_delay_cycles )
int timing=9;
int timing_max=10;

void beat()
{
	switch(timing) {
		case 0: _delay_ms(5); break;
		case 1: _delay_ms(10); break;
		case 2: _delay_ms(15); break;
		case 3: _delay_ms(20); break;
		case 4: _delay_ms(25); break;
		case 5: _delay_ms(30); break;
		case 6: _delay_ms(35); break;
		case 7: _delay_ms(40); break;
		case 8: _delay_ms(45); break;
		case 9: _delay_ms(50); break;
	}
	PORTB^=0b00000010;
	//PORTC^=0b000100; miganie diod� przy guziczkach
}

void beat_plus()
{
	switch(timing)	{
		case 0: _delay_ms(2); break;
		case 1: _delay_ms(4); break;
		case 2: _delay_ms(6); break;
		case 3: _delay_ms(8); break;
		case 4: _delay_ms(10); break;
		case 5: _delay_ms(12); break;
		case 6: _delay_ms(14); break;
		case 7: _delay_ms(16); break;
		case 8: _delay_ms(18); break;
		case 9: _delay_ms(20); break;
	}
}

int main(void)
{
	
	// nie u�ywany
	OUT_INIT_PORT(B)
	PORTB=0b111111;
	
	// sterowanie silniczkami
	OUT_INIT_PORT(D)
	PORTD=0b00010001;

	// nie u�ywane bity
	OUT_INIT_PORT(C)
	OUT_ON(C,0)
	OUT_ON(C,1)
	
	// przyciski
	IN_INIT(C,3)
	#define LEFT_TEST IN_TEST(C,3)
	IN_INIT(C,4)
	#define FWD_TEST IN_TEST(C,4)
	IN_INIT(C,5)
	#define RIGHT_TEST IN_TEST(C,5)
	
	int left=0, right=0;
	
	LED_OUT(9-timing+'0')
	
	while(1)
	{
		beat();

		if (FWD_TEST&&LEFT_TEST) {
			DEC_MOD(timing,timing_max)
			LED_OUT(9-timing+'0')
			_delay_ms(150);
		}

		if (FWD_TEST&&RIGHT_TEST) {
			INC_MOD(timing,timing_max)
			LED_OUT(9-timing+'0')
			_delay_ms(150);
		}

		if (FWD_TEST) {
			FWD(left)
			FWD(right)
		}
		
		if (LEFT_TEST && (!RIGHT_TEST)) {
			BCK(left)
			FWD(right)
			beat_plus();
		}
		
		if (RIGHT_TEST && (!LEFT_TEST)) {
			FWD(left)
			BCK(right)
			beat_plus();
		}
		
		if (LEFT_TEST&&RIGHT_TEST) {
			BCK(left)
			BCK(right)
		}
		
		PORTD = wavedrive_hi_byte[left] | wavedrive_lo_byte[right];
	}
}

