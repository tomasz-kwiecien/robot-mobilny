/*
 * char7seg.h
 *
 * Created: 2016-10-15 11:35:01
 *  Author: MD
 * wersja 1.3, poprawa ! ~, poprawa x b, zmiana nazwy
 */ 

/* SPOS�B U�YCIA:

przyk�adowe podpi�cie kabla od panelu: aC0 fC1 bB5 gB4 cB3 eB2 hB1 dB0, wsp�lna anoda
st�d konfiguracja makra: a-C0 b-B5 c-B3 d-B0 e-B2 f-C1 g-B4 h-B1

KOD:
int BUFFER;  // zmienna dla drobnego przyspieszenia dzia�ania
#define LED_OUT(char_code) \
	BUFFER = ~ ASCII7SEG [char_code-32]; \
	LED_OUT_BITS(BUFFER, C,0, B,5, B,3, B,0, B,2, C,1, B,4, B,1)

*/

#ifndef CHAR7SEG_H_
#define CHAR7SEG_H_

// przybli�enie znak�w ASCII na wy�wietlaczu 7 segmentowym
// znaki czytelne na led: 0123456789 ACEFGHJLOPSQUYZ bcdhnoru =",.^?
// reszta znak�w to graficzne przybli�enia
// znaki w tablicy s� od spacji, na razie tylko alfanumeryczne
// nie ma standardu dla takiego przybli�enia znak�w
// wiki:Seven-segment display character representations
const char ASCII7SEG[]={   // z tego nie generuje si� �adnego kodu, tylko dane
	0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,
	63,6,91,79,102,109,125,7,
	127,111,0,0,0,0,0,0,

	0,119,95,57,31,121,113,61,
	118,48,14,122,56,43,55,47,
	115,103,117,101,49,62,30,29,
	54,110,83,0,0,0,0,0,

	//0,119,79,57,15,121,113,61,
	//118,48,14,122,56,43,55,63,
	//115,103,117,109,49,62,30,29,
	//54,110,91,0,0,0,0,0,

	0,95,124,88,94,89,81,101,
	116,16,12,112,24,82,84,92,
	51,71,80,101,120,28,20,42,
	18,106,82,0,0,0,0,0
};

#define CHECK_AND_SET(byte,mask,port,pin) if ((byte) & (mask)) PORT##port |= (1<<pin); else PORT##port &= ~(1<<pin);

#define LED_OUT_BITS(bit_code, ao,ai, bo,bi, co,ci, do,di, eo,ei, fo,fi, go,gi, ho,hi) \
	CHECK_AND_SET(bit_code,0b00000001,ao,ai) \
	CHECK_AND_SET(bit_code,0b00000010,bo,bi) \
	CHECK_AND_SET(bit_code,0b00000100,co,ci) \
	CHECK_AND_SET(bit_code,0b00001000,do,di) \
	CHECK_AND_SET(bit_code,0b00010000,eo,ei) \
	CHECK_AND_SET(bit_code,0b00100000,fo,fi) \
	CHECK_AND_SET(bit_code,0b01000000,go,gi) \
	CHECK_AND_SET(bit_code,0b10000000,ho,hi)

#endif /* CHAR7SEG_H_ */