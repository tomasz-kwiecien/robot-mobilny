
/*
 * ascii7seg.h
 *
 * Created: 2016-10-15 14:45:49
 *  Author: Tomasz Kwiecie�
 * wersja 1.1, reorganizacja, ale dalej b��d w kodzie, ! zamiast ~
 */ 

#ifndef ASCII7SEG_H_
#define ASCII7SEG_H_

// przybli�enie znak�w ASCII na wy�wietlaczu 7 segmentowym
// znaki czytelne na led: 0123456789 ACEFGHJLOPSQUYZ bcdhnoru =",.^?
// reszta znak�w to graficzne przybli�enia
// znaki w tablicy s� od spacji, na razie tylko alfanumeryczne
// nie ma standardu dla takiego przybli�enia znak�w
// wiki:Seven-segment display character representations
const char a7s_led[]={
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,	
63,6,91,79,102,109,125,7,
127,111,0,0,0,0,0,0,

0,119,95,57,31,121,113,61,
118,48,14,122,56,43,55,47,
115,103,117,109,49,62,30,29,
54,110,91,0,0,0,0,0,

//0,119,79,57,15,121,113,61,
//118,48,14,122,56,43,55,63,
//115,103,117,109,49,62,30,29,
//54,110,91,0,0,0,0,0,

0,95,124,88,94,89,81,101,
116,16,12,112,24,82,84,92,
51,71,80,101,120,28,20,42,
18,106,82,0,0,0,0,0
};

// !!!!!!!! B��D DALEJ !!!!!!!!!!!
#define A7S_OUT_OFF(port,pin) PORT##port &= !(1<<pin);
#define A7S_OUT_ON(port,pin) PORT##port |= (1<<pin);

// dla paneli ze wsp�ln� katod�
#define A7S_LED_OUT_BITS(bit_code,ai,ao,bi,bo,ci,co,di,do,ei,eo,fi,fo,gi,go,hi,ho) \
	if (bit_code & 0x00000001) A7S_OUT_ON(ai,ao) else A7S_OUT_OFF(ai,ao) \
	if (bit_code & 0x00000010) A7S_OUT_ON(bi,bo) else A7S_OUT_OFF(bi,bo) \
	if (bit_code & 0x00000100) A7S_OUT_ON(ci,co) else A7S_OUT_OFF(ci,co) \
	if (bit_code & 0x00001000) A7S_OUT_ON(di,do) else A7S_OUT_OFF(di,do) \
	if (bit_code & 0x00010000) A7S_OUT_ON(ei,eo) else A7S_OUT_OFF(ei,eo) \
	if (bit_code & 0x00100000) A7S_OUT_ON(fi,fo) else A7S_OUT_OFF(fi,fo) \
	if (bit_code & 0x01000000) A7S_OUT_ON(gi,go) else A7S_OUT_OFF(gi,go) \
	if (bit_code & 0x10000000) A7S_OUT_ON(hi,ho) else A7S_OUT_OFF(hi,ho) 
	
	// ===============
	// w tym ca�ym g�szczu kodu nie by�o wida�, �e maska jest szesnastkowa...
	// zwraca�em uwag� tylko na to, �e s� bity kolejno
	
	// z makrami chodzi mi�dzy innymi o to, �eby nie powtarza� parametr�w
	// tutaj by�y powtarzane i to przyci�ga�o my�l do tego fragmentu
	// zbytnia redundancja kodu powoduje zm�czenie wzroku i przeoczenie b��d�w gdzie indziej
	
#define A7S_LED_OUT_POS(char_code, bit_code_buffer, ai,ao,bi,bo,ci,co,di,do,ei,eo,fi,fo,gi,go,hi,ho) \
	bit_code_buffer=a7s_led[char_code-32]; \
	A7S_LED_OUT_BITS(bit_code_buffer,ai,ao,bi,bo,ci,co,di,do,ei,eo,fi,fo,gi,go,hi,ho) 

#define A7S_LED_OUT_NEG(char_code, bit_code_buffer, ai,ao,bi,bo,ci,co,di,do,ei,eo,fi,fo,gi,go,hi,ho) \
	bit_code_buffer=~a7s_led[char_code-32]; \
	A7S_LED_OUT_BITS(bit_code_buffer,ai,ao,bi,bo,ci,co,di,do,ei,eo,fi,fo,gi,go,hi,ho) 

/* 
SPOS�B U�YCIA :
przyk�adowe podpi�cie kabla od panelu: aC0 fC1 bB5 gB4 cB3 eB2 hB1 dB0, wsp�lna anoda
st�d konfiguracja makra: a-C0 b-B5 c-B3 d-B0 e-B2 f-C1 g-B4 h-B1

int A7S_BUFFER;  // zmienna dla drobnego przyspieszenia dzia�ania
#define LED_OUT(char_code) A7S_LED_OUT_NEG(char_code, A7S_BUFFER, C,0, B,5, B,3, B,0, B,2, C,1, B,4, B,1)

*/

#endif 