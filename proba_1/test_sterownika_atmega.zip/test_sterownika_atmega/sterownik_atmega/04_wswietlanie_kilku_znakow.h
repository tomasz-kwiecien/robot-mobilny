
/* 01_wyswietlanie_panelem

SPRZ�T:

lpt1, severino, m8 #1, 16000000mhz

FRAME_06, silnik lewy D7654, silnik prawy D3210
ULN na p�ytce stykowej, GND i 9V (12V) wzi�te z pin�w p�ytki
zasilanie z akumulatora wpi�te do gniazda p�ytki

Przyciski na C3-P1 C4-P2 C5-P3, lewo, naprz�d, prawo
P1+P3 wstecz, P2+P3 taktowanie szybsze o 5+2, P1+P2 taktowanie wolniejsze o 5+2

pocz�tkowe taktowanie 50+20

panel led podpi�cy z opornikami 1,5k, zapalane stanem niskim
podpi�cie kabla od panelu: aC0 fC1 bB5 gB4 cB3 eB2 hB1 dB0, h-decimal point
h u�yte jako kontrolka

WYNIKI :

klasa i biblioteki daj� du�y narzut przy kompilacji
pr�ba 03:
Program Memory Usage: 1510 bytes 18,4 % Full
Data Memory Usage:     110 bytes 10,7 % Full
pr�ba 04:
Program Memory Usage: 4141 bytes 50,6 % Full
Data Memory Usage:     246 bytes 24,0 % Full

port r�wnoleg�y daje za s�aby pr�d �eby zasila� silniki
wy�wietlanie kilku znak�w jest mo�liwe, ale lepiej jak tak nie migaj�
tu jeszcze s� jakie� b��dy w zmienianiu, ale ju� ich nie b�d� szuka�
ca�o�� si� zrobi�a zbyt poz��czana ze sob�

*/

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>
#include "ports.h"

//----------------- panel led

#include "char7seg.h"
#include <string.h>
#include <stdio.h>

//podpi�cie kabla od panelu: aC0 fC1 bB5 gB4 cB3 eB2 hB1 dB0, wsp�lna anoda
//konfiguracja makra: a-C0 b-B5 c-B3 d-B0 e-B2 f-C1 g-B4 h-B1
int BUFFER;  // zmienna dla drobnego przyspieszenia dzia�ania
#define LED_OUT(char_code) \
	BUFFER = ~ ASCII7SEG [char_code-32]; \
	LED_OUT_BITS(BUFFER, C,0, B,5, B,3, B,0, B,2, C,1, B,4, B,1)
	
char toStringBuffer[10];	
char* toString(int v) {
	//itoa(v,toStringBuffer,10);
	sprintf(toStringBuffer,"%d",v);
	return toStringBuffer;
}
char* toString(double v) {
	sprintf(toStringBuffer,"%G",v);
	return toStringBuffer;
}

class LedPanel {
	char text[100];
	int current;
  public:
	LedPanel() {
		// ACEFGHJLOPSQUYZ bcdhnoru
		strcpy(text,"LED TEST  ");
		current=0;
		LED_OUT(text[current]);
	}
	void changeText(char* _text) {
		strcpy(text,_text);
		current=0;
		LED_OUT(text[current]);
	}
	void advanceDisplay() {
		current = (current + 1) % strlen(text);
		LED_OUT(text[current]);
	}
	void changeText(int v) {
		strcpy(text,toString(v));
		strcat(text," ");  //op�nienie wy�wietlania mi�dzy cyframi
		current=0;
		LED_OUT(text[current]);
	}
	
};
// mo�na potem zamkn�� ca�y mechanizm do klasy
// a do rejestr�w odwo�ywa� si� bezpo�rednio indeksuj�c pami��
// tam jest gdzie� nisko makro dla bie�acych rejestr�w
// ale mo�e �atwiej b�dzie zrobi� swoje z opcjami kompilacji zale�nymi od procesora
//
// od�wie�anie led niekoniecznie musi by� w przerwaniu
// je�eli taktowanie jest istotne dla robota

LedPanel panel;
int led_timing=0;
int led_interval=500;
#define LED_REFRESH if (led_timing>led_interval) {led_timing=0; panel.advanceDisplay();}

// tu mo�na wstawi� te� inne procedury przerwaniowe
#define DELAY(ms) {for(int i=0; i<(ms); i++) {_delay_ms(1); led_timing++; LED_REFRESH} }

//------------------ sterowanie silniczkami

static unsigned char wavedrive_lo_byte[4]={
	0b00000001,
	0b00000010,
	0b00000100,
	0b00001000
};

static unsigned char wavedrive_hi_byte[4]={
	0b00010000,
	0b00100000,
	0b01000000,
	0b10000000
};

#define FWD(p) p = (p+1)%4;
#define BCK(p) p = (p+3)%4;

//------------------- taktowanie silniczk�w

#define INC_MOD(n,m) n=(n+1)%m;
#define DEC_MOD(n,m) n=(n+m-1)%m;

// _delay_ms oczekuje sta�ej jako argumentu  ( __builtin_avr_delay_cycles )
int timing=9;  // warto�� symboliczna
int timing_max=10;

void beat()
{
	DELAY((timing+1)*5)
	PORTB^=0b00000010;   // mignanie decimal pointem
}

void beat_plus()
{
	DELAY((timing+1)*2)
}

int main(void)
{
	
	// nie u�ywany
	OUT_INIT_PORT(B)
	PORTB=0b111111;
	
	// sterowanie silniczkami
	OUT_INIT_PORT(D)
	PORTD=0b00010001;

	// nie u�ywane bity
	OUT_INIT_PORT(C)
	OUT_ON(C,0)
	OUT_ON(C,1)
	
	// przyciski
	IN_INIT(C,3)
	#define LEFT_TEST IN_TEST(C,3)
	IN_INIT(C,4)
	#define FWD_TEST IN_TEST(C,4)
	IN_INIT(C,5)
	#define RIGHT_TEST IN_TEST(C,5)
	
	int left=0, right=0;

    //�eby na pocz�tku wy�wietli� tekst testowy
	//panel.changeText((timing+1)*5);
	
	while(1)
	{
		beat();

		if (FWD_TEST&&LEFT_TEST) {
			INC_MOD(timing,timing_max)
			panel.changeText((timing+1)*5);
			_delay_ms(500);
		}

		if (FWD_TEST&&RIGHT_TEST) {
			DEC_MOD(timing,timing_max)
			panel.changeText((timing+1)*5);
			_delay_ms(500);
		}

		if (FWD_TEST) {
			FWD(left)
			FWD(right)
		}
		
		if (LEFT_TEST && (!RIGHT_TEST)) {
			BCK(left)
			FWD(right)
			beat_plus();
		}
		
		if (RIGHT_TEST && (!LEFT_TEST)) {
			FWD(left)
			BCK(right)
			beat_plus();
		}
		
		if (LEFT_TEST&&RIGHT_TEST) {
			BCK(left)
			BCK(right)
		}
		
		PORTD = wavedrive_hi_byte[left] | wavedrive_lo_byte[right];
	}
}

