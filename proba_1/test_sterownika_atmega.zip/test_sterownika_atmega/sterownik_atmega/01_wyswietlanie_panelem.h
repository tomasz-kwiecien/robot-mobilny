
/* 01_wyswietlanie_panelem

SPRZ�T:

lpt1, severino, m8 #1, 16000000mhz

FRAME_06, silnik lewy D7654, silnik prawy D3210
ULN na p�ytce stykowej, GND i 9V (12V) wzi�te z pin�w p�ytki
zasilanie z akumulatora wpi�te do gniazda p�ytki

Przyciski na C3-P1 C4-P2 C5-P3, lewo, naprz�d, prawo
P1+P3 wstecz, P2+P3 taktowanie szybsze o 5+2, P1+P2 taktowanie wolniejsze o 5+2

pocz�tkowe taktowanie 50+20

panel led podpi�cy z opornikami 1,5k, zapalane stanem niskim
podpi�cie kabla od panelu: aC0 fC1 bB5 gB4 cB3 eB2 hB1 dB0, h-decimal point
h u�yte jako kontrolka

przyda�aby si� zworka do wy��czania kontrolki na p�ytce

WYNIKI :

nie dzia�a wy�wietlanie, po naci�ni�ciu P2+P3 przestaje dzia�a� sterowanie silnikami
przypadkowo mia�em jednocze�nie w��czone zasilanie i podpi�ty programator

*/

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>
#include "ports.h"

//#include "ascii7seg.h"
// ver 1.1
//========================

const char a7s_led[]={
	0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,
	63,6,91,79,102,109,125,7,
	127,111,0,0,0,0,0,0,

	0,119,79,57,15,121,113,61,
	118,48,14,122,56,43,55,63,
	115,103,117,109,49,62,30,29,
	54,110,91,0,0,0,0,0,

	0,95,124,88,94,89,81,101,
	116,16,12,112,24,82,84,92,
	51,71,80,101,120,28,20,42,
	18,106,82,0,0,0,0,0
};

#define A7S_OUT_OFF(port,pin) PORT##port &= !(1<<pin);
#define A7S_OUT_ON(port,pin) PORT##port |= (1<<pin);

// dla paneli ze wsp�ln� katod�
#define A7S_LED_OUT_BITS(bit_code,ai,ao,bi,bo,ci,co,di,do,ei,eo,fi,fo,gi,go,hi,ho) \
if (bit_code & 0x00000001) A7S_OUT_ON(ai,ao) else A7S_OUT_OFF(ai,ao) \
if (bit_code & 0x00000010) A7S_OUT_ON(bi,bo) else A7S_OUT_OFF(bi,bo) \
if (bit_code & 0x00000100) A7S_OUT_ON(ci,co) else A7S_OUT_OFF(ci,co) \
if (bit_code & 0x00001000) A7S_OUT_ON(di,do) else A7S_OUT_OFF(di,do) \
if (bit_code & 0x00010000) A7S_OUT_ON(ei,eo) else A7S_OUT_OFF(ei,eo) \
if (bit_code & 0x00100000) A7S_OUT_ON(fi,fo) else A7S_OUT_OFF(fi,fo) \
if (bit_code & 0x01000000) A7S_OUT_ON(gi,go) else A7S_OUT_OFF(gi,go) \
if (bit_code & 0x10000000) A7S_OUT_ON(hi,ho) else A7S_OUT_OFF(hi,ho)

#define A7S_LED_OUT_POS(char_code, bit_code_buffer, ai,ao,bi,bo,ci,co,di,do,ei,eo,fi,fo,gi,go,hi,ho) \
bit_code_buffer=a7s_led[char_code-32]; \
A7S_LED_OUT_BITS(bit_code_buffer,ai,ao,bi,bo,ci,co,di,do,ei,eo,fi,fo,gi,go,hi,ho)

#define A7S_LED_OUT_NEG(char_code, bit_code_buffer, ai,ao,bi,bo,ci,co,di,do,ei,eo,fi,fo,gi,go,hi,ho) \
bit_code_buffer=~a7s_led[char_code-32]; \
A7S_LED_OUT_BITS(bit_code_buffer,ai,ao,bi,bo,ci,co,di,do,ei,eo,fi,fo,gi,go,hi,ho)

//==========================

// podpi�cie kabla od panelu: aC0 fC1 bB5 gB4 cB3 eB2 hB1 dB0, wsp�lna anoda
// konfiguracja makra: a-C0 b-B5 c-B3 d-B0 e-B2 f-C1 g-B4 h-B1
int A7S_BUFFER;  // zmienna dla drobnego przyspieszenia dzia�ania
#define LED_OUT(char_code) \
	A7S_LED_OUT_NEG(char_code, A7S_BUFFER, C,0, B,5, B,3, B,0, B,2, C,1, B,4, B,1)

static unsigned char wavedrive_lo_byte[4]={
	0b00000001,
	0b00000010,
	0b00000100,
	0b00001000
};

static unsigned char wavedrive_hi_byte[4]={
	0b00010000,
	0b00100000,
	0b01000000,
	0b10000000
};

#define FWD(p) p = (p+1)%4;
#define BCK(p) p = (p+3)%4;

// wiele taktowa�

#define INC_MOD(n,m) n=(n+1)%m;
#define DEC_MOD(n,m) n=(n+m-1)%m;

// _delay_ms oczekuje sta�ej jako argumentu  ( __builtin_avr_delay_cycles )
int timing=9;
int timing_max=10;

void beat()
{
	switch(timing) {
		case 0: _delay_ms(5); break;
		case 1: _delay_ms(10); break;
		case 2: _delay_ms(15); break;
		case 3: _delay_ms(20); break;
		case 4: _delay_ms(25); break;
		case 5: _delay_ms(30); break;
		case 6: _delay_ms(35); break;
		case 7: _delay_ms(40); break;
		case 8: _delay_ms(45); break;
		case 9: _delay_ms(50); break;
	}
	PORTB^=0b00100010;
}

void beat_plus()
{
	switch(timing)	{
		case 0: _delay_ms(2); break;
		case 1: _delay_ms(4); break;
		case 2: _delay_ms(6); break;
		case 3: _delay_ms(8); break;
		case 4: _delay_ms(10); break;
		case 5: _delay_ms(12); break;
		case 6: _delay_ms(14); break;
		case 7: _delay_ms(16); break;
		case 8: _delay_ms(18); break;
		case 9: _delay_ms(20); break;
	}
}

int main(void)
{
	
	// nie u�ywany
	OUT_INIT_PORT(B)
	PORTB=0b111111;
	
	// sterowanie silniczkami
	OUT_INIT_PORT(D)
	PORTD=0b00010001;

	// nie u�ywane bity
	OUT_INIT_PORT(C)
	OUT_ON(C,0)
	OUT_ON(C,1)
	// przyciski
	IN_INIT(C,3)
	#define LEFT_TEST IN_TEST(C,3)
	IN_INIT(C,4)
	#define FWD_TEST IN_TEST(C,4)
	IN_INIT(C,5)
	#define RIGHT_TEST IN_TEST(C,5)
	
	int left=0, right=0;
	
	while(1)
	{
		beat();

		if (FWD_TEST&&LEFT_TEST) {
			DEC_MOD(timing,timing_max)
			LED_OUT(timing+'0')
			_delay_ms(500);
		}

		if (FWD_TEST&&RIGHT_TEST) {
			INC_MOD(timing,timing_max)
			LED_OUT(timing+'0')
			_delay_ms(500);
		}

		if (FWD_TEST) {
			FWD(left)
			FWD(right)
		}
		
		if (LEFT_TEST && (!RIGHT_TEST)) {
			BCK(left)
			FWD(right)
			beat_plus();
		}
		
		if (RIGHT_TEST && (!LEFT_TEST)) {
			FWD(left)
			BCK(right)
			beat_plus();
		}
		
		if (LEFT_TEST&&RIGHT_TEST) {
			BCK(left)
			BCK(right)
		}
		
		PORTD = wavedrive_hi_byte[left] | wavedrive_lo_byte[right];
	}
}

