
/* 01_wyswietlanie_panelem

SPRZ�T:

programator lpt1, severino, m8 egzemplarz#1, 16000000mhz

dwa silniki M42SP-5P
dwa sterowniki A4988 Pololu item 2128
lewy DIR-D3 STEP-D2, prawy DIR-D1 STEP-D0

dzia�a tylko jeden wi�c oba silniczki podpi�te do niego
drugi z odwr�con� kolejno�ci� sygna��w
co daje tylko ruch: P1-wstecz, P2-naprz�d

Przyciski na C3-P1 C4-P2 C5-P3, lewo, naprz�d, prawo
P1+P3 wstecz, P2+P3 taktowanie szybsze o 5+2, P1+P2 taktowanie wolniejsze o 5+2

pocz�tkowe taktowanie, 50ms jazda prosta, 70ms skr�ty

panel led podpi�cy z opornikami 1,5k, zapalane stanem niskim
podpi�cie kabla od panelu: aC0 fC1 bB5 gB4 cB3 eB2 hB1 dB0, h-decimal point

WYNIKI:

przy spadku napi�cia akumulatora sterownik sie potrafi zaci��
prawy silnik tylko wibruje


*/

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>
#include "ports.h"
#include "char7seg.h"

//podpi�cie kabla od panelu: aC0 fC1 bB5 gB4 cB3 eB2 hB1 dB0, wsp�lna anoda
//konfiguracja makra: a-C0 b-B5 c-B3 d-B0 e-B2 f-C1 g-B4 h-B1
int BUFFER;  // zmienna dla drobnego przyspieszenia dzia�ania
#define LED_OUT(char_code) \
	BUFFER = ~ ASCII7SEG [char_code-32]; \
	LED_OUT_BITS(BUFFER, C,0, B,5, B,3, B,0, B,2, C,1, B,4, B,1)
	// lepsze jest numerowanie pin�w jak w bibliotece arduino

// wiele taktowa�

#define DEC_LIM(d,min,max,step) d-=step; if (d<min) d=max;
#define INC_LIM(d,min,max,step) d+=step; if (d>max) d=min;

int timing=25;
#define T_MIN 1
#define T_MAX 35
#define T_STP 1

// _delay_ms oczekuje sta�ej jako argumentu  ( __builtin_avr_delay_cycles )
#define DELAY(ms) for (int i=0; i<(ms); i++) _delay_ms(1);

void beat()
{
	//dodatkowe odj�cie 2ms, ze wzgl�du na MIEJSCE_01
	//�eby by� odst�p stanu niskiego mi�dzy pulsami STEP
	DELAY(timing-1)
	PORTB^=0b00000010;
	//PORTC^=0b000100; miganie diod� przy guziczkach
}

//lewy DIR-D3 STEP-D2, prawy DIR-D1 STEP-D0
#define SET_BIT(byte,bit,value) if ((value)==1) (byte)|=(1<<(bit)); else (byte)&=(~(1<<(bit)));
#define L_DIR(b) SET_BIT(PORTD,3,b)
#define L_STP(b) SET_BIT(PORTD,2,b)
#define R_DIR(b) SET_BIT(PORTD,1,b)
#define R_STP(b) SET_BIT(PORTD,0,b)

// silniczki s� odwr�cone
// dla poprzedniego sterownika (ULN) by�o to kompensowane odwr�ceniem kabla
#define L_FWD 1
#define L_BCK 0
#define R_FWD 0
#define R_BCK 1

char hex_digit(int n) {
	//                           12        20        30   
	//                  012345678901234567890123456789012345, cyfry 0-35 
	const char *digits="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    return digits[n];
}

int main(void)
{
	
	// nie u�ywany
	OUT_INIT_PORT(B)
	PORTB=0b111111;
	
	// sterowanie silniczkami
	OUT_INIT_PORT(D)
	PORTD=0b00010001;

	// nie u�ywane bity
	OUT_INIT_PORT(C)
	OUT_ON(C,0)
	OUT_ON(C,1)
	
	// przyciski
	IN_INIT(C,3)
	#define LEFT_TEST IN_TEST(C,3)
	IN_INIT(C,4)
	#define FWD_TEST IN_TEST(C,4)
	IN_INIT(C,5)
	#define RIGHT_TEST IN_TEST(C,5)
	
	LED_OUT(hex_digit(timing))
	
	while(1)
	{

		if (FWD_TEST&&LEFT_TEST) {
			INC_LIM(timing,T_MIN,T_MAX,T_STP)
			LED_OUT(hex_digit(timing))
			_delay_ms(150);
		}

		if (FWD_TEST&&RIGHT_TEST) {
			DEC_LIM(timing,T_MIN,T_MAX,T_STP)
			LED_OUT(hex_digit(timing))
			_delay_ms(150);
		}

		if (FWD_TEST) {
			// chyba najpierw trzeba ustawi� kierunek
			L_DIR(L_FWD)
			R_DIR(R_FWD)  //silniczki s� odwr�cone
			// dla poprzedniego sterownika by�o to kompensowane odwr�ceniem kabla
			// tu jest problem z jednoczesno�ci�
			L_STP(1)
			R_STP(1)
		}
		
		if (LEFT_TEST && (!RIGHT_TEST)) {
			L_DIR(L_BCK)
			R_DIR(R_FWD)
			L_STP(1)
			R_STP(1)
		}
		
		if (RIGHT_TEST && (!LEFT_TEST)) {
			L_DIR(L_FWD)
			R_DIR(R_BCK)
			L_STP(1)
			R_STP(1)
		}
		
		if (LEFT_TEST&&RIGHT_TEST) {
			L_DIR(L_BCK)
			R_DIR(R_BCK)
			L_STP(1)
			R_STP(1)
		}
		
		//MIEJSCE_01
		DELAY(1)
		PORTD=0;  // ustawi�em pulsy na 1ms
		beat();

	}
}

