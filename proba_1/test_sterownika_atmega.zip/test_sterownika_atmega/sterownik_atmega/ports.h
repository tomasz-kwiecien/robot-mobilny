/*
 * ports.h
 *
 * Created: 2016-10-15 14:45:49
 *  Author: Tomasz Kwiecie�
 * wersja 1.1, poprawiony b��d w zapisie negacji
 */ 

#ifndef PORTS_H_
#define PORTS_H_

// inicjowanie pojedynczych bit�w jako wej�cie lub wyj�cie
#define OUT_INIT(port,pin) DDR##port |= (1<<pin); PORT##port &= ~(1<<pin);
#define OUT_OFF(port,pin)  PORT##port &= ~(1<<pin);
#define OUT_ON(port,pin)   PORT##port |= (1<<pin);
#define OUT_XOR(port,pin)  PORT##port ^= (1<<pin);
#define IN_INIT(port,pin)  DDR##port &= ~(1<<pin); PORT##port |= (1<<pin);
#define IN_TEST(port,pin)  (!(PIN##port & (1<<pin)))
// inicjowanie ca�ego portu jako wej�cie z pull-up lub wyj�cie
#define OUT_INIT_PORT(port) DDR##port = 0xFF; PORT##port = 0x00;
#define IN_INIT_PORT(port)  DDR##port = 0x00; PORT##port = 0xFF;

#endif /* PORTS_H_ */