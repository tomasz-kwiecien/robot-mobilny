
/* 16

SPRZ�T :
lpt1, severino, m8 #1, 16000000mhz

panel led podpi�cy z opornikami 1,5k, zapalane stanem niskim

WYNIK:
wszystkie segmenty migaj�

*/

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>

int main(void)
{
	DDRB=0xFF;
	DDRC=0xFF;
	DDRD=0xFF;
	while(1)
	{
		PORTD^=0xFF;
		PORTB^=0xFF;
		PORTC^=0xFF;
		_delay_ms(500);
	}
}
