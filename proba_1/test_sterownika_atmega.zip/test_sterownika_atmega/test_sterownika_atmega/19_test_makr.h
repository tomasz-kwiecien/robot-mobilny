
/* 19

SPRZ�T :

lpt1, severino, m8 #1, 16000000mhz

panel led podpi�cy z opornikami 1,5k, zapalane stanem niskim
kabel wpi�ty do portu D, proste przepisywanie sekwencji segment�w

WYNIK:
segmenty si� zapalaj� przypadkowo

*/

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>
#include "ports.h"
// przybli�enie znak�w ASCII na wy�wietlaczu 7 segmentowym
// znaki czytelne na led: 0123456789 ACEFGHJLOPSQUYZ bcdhnoru =",.^?
// reszta znak�w to graficzne przybli�enia
// znaki w tablicy s� od spacji, na razie tylko alfanumeryczne
// nie ma standardu dla takiego przybli�enia znak�w
const char led[]={
	0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,
	63,6,91,79,102,109,125,7,
	127,111,0,0,0,0,0,0,

	0,119,79,57,15,121,113,61,
	118,48,14,122,56,43,55,63,
	115,103,117,109,49,62,30,29,
	54,110,91,0,0,0,0,0,

	0,95,124,88,94,89,81,101,
	116,16,12,112,24,82,84,92,
	51,71,80,101,120,28,20,42,
	18,106,82,0,0,0,0,0
};

int main(void)
{
	DDRD=0xff;
	PORTD=0xff;
	
	while(1)
	{
		for (int c='0'; c<='z';c++){
			PORTD=~led[c];
			_delay_ms(500);
		}
	}
}
