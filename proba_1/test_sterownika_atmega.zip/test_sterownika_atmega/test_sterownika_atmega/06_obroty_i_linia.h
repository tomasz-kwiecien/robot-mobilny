
/* 06_obroty_i_linia

SPRZ�T :

lpt1, severino, m8 #1, 16000000mhz
atmega8 ma porty 6,6,8 bitowe: B 0-5, C 0-5, D 0-7
�wiate�ko kontrolne jest na B5, sz�stym bicie portu B

FRAME_06, silnik lewy D7654, silnik prawy D3210
ULN na p�ytce stykowej, GND i 9V (12V) wzi�te z pin�w p�ytki
zasilanie z akumulatora wpi�te do gniazda p�ytki

Przyciski na C3 C4 C5, lewo, naprz�d, prawo; lewo+prawo=wstecz

WYNIKI :

na g�adkim stole jest wi�ksza przyczepno�� gumy do pod�o�a i wi�ksze tarcie 
na 50ms buksuje przy obrotach, obr�t w lewo jest s�abszy, bo wtedy oba CCW
czy og�lnie silniczki krokowe s� silniejsze w jednym kierunku ?

pe�na manewrowo�� to 4 przyciski

*/

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>
#include "ports.h"

#define BEAT _delay_ms(60); PORTB^=0b00100000;

// sterowanie silnikami
unsigned char seq_fwd[4]={
	// lewy D7-4, prawy D3-0
	0b00010001,
	0b00100010,
	0b01000100,
	0b10001000
};

unsigned char seq_lft[4]={
	// lewy D7-4, prawy D3-0
	0b10000001,
	0b01000010,
	0b00100100,
	0b00011000
};

unsigned char seq_rgt[4]={
	// lewy D7-4, prawy D3-0
	0b00011000,
	0b00100100,
	0b01000010,
	0b10000001
};

unsigned char seq_bck[4]={
	// lewy D7-4, prawy D3-0
	0b10001000,
	0b01000100,
	0b00100010,
	0b00010001
};

int main(void)
{
	
	// nie u�ywany
	OUT_INIT_PORT(B)
	
	// sterowanie silniczkami
	OUT_INIT_PORT(D)

	// przyciski
	IN_INIT(C,3)
	#define LEFT_TEST IN_TEST(C,3)
	IN_INIT(C,5)
	#define RIGHT_TEST IN_TEST(C,5)
	IN_INIT(C,4)
	#define FWD_TEST IN_TEST(C,4)
	
	int seq_no=0;
	while(1)
	{
		BEAT
		if ((FWD_TEST&&LEFT_TEST) || (FWD_TEST&&RIGHT_TEST))
			continue;
		if (FWD_TEST)
			PORTD = seq_fwd[seq_no];
		if (LEFT_TEST)
			PORTD = seq_lft[seq_no];
		if (RIGHT_TEST)
			PORTD = seq_rgt[seq_no];
		if (LEFT_TEST&&RIGHT_TEST)
			PORTD = seq_bck[seq_no];
		seq_no = (seq_no+1)%4;
	}
}





