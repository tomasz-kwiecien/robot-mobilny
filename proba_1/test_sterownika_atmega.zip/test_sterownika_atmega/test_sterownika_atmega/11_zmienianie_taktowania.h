
/* 11_zmienianie_taktowania

SPRZ�T :

lpt1, severino, m8 #1, 16000000mhz
atmega8 ma porty 6,6,8 bitowe: B 0-5, C 0-5, D 0-7
�wiate�ko kontrolne jest na B5, sz�stym bicie portu B

FRAME_06, silnik lewy D7654, silnik prawy D3210
ULN na p�ytce stykowej, GND i 9V (12V) wzi�te z pin�w p�ytki
zasilanie z akumulatora wpi�te do gniazda p�ytki

Przyciski na C3 C4 C5, lewo, naprz�d, prawo
C3+C5 wstecz, C3+C4 taktowanie szybsze, C4+C5 taktowanie wolniejsze

piezo na B2-B1

WYNIKI :

potrzebny jest klawisz z autorepetycj�, 
reaguj�cy od razu na naci�ni�cie, a po op�nieniu generuj�cy takt maksymalny
(na razie nie mam pomys�u jak to zapisa�, nie mo�e by� op�nienia w p�tli,
 powinno by� debounce 10ms, czyli raczej op�nienie 1ms, albo 10
 a po 30ms autorepetycja ze sprawdzaniem klawisza
 albo mo�e sprz�towo wyg�adzi� klawisz ? obw�d do tego powinien by� na p�ytce
 fajna by by�a p�ytka z elementami smd do tego, 
 trzeba rezystor i kondensator dla ka�dego przycisku
 
 jak jest piezo na B4-B5 to nie da si� zaprogramowa�, bo to s� SCK i MISO
 podczas programowania zapala si� dioda kontrolna, na SCK
 
 piezo buczy szybciej na B3-B2 ??
 
 napi�cie akumulatora spad�o do 10.93
 lewy buksuje przy skr�tach, zaczyna buksowa� przy naprz�d, w ty� jeszcze jedzie
 
 lepsza by by�a wtyczka do akumulatora i �adowarki ni� kostki
 
 akumulator jest chyba przeci��ony
 247, 226 na hamowaniu i w ruchu
 
 wysun�� si� z p�ytki uk�ad uln
 kilka razy wymienia�em zasilanie, w ko�cy sprawdza�em bezpo�rednio silniki,
 zanim znalaz�em ten b��d, bo my�la�em �e akumulatory s� roz�adowane albo silniki si� zepsu�y
 
 piezo na B5-B4 przeszkadza w zaprogramowaniu
 
 Akumulator �elowy 12V 0,8 Ah XTREME, 19z�
 
 Charakterystyka:

 Akumulator �elowy wyprodukowany w technologii AGM (Absorbent Glass Mat). Wysoka jako�� wykonania p�yt o�owiowych oraz elektrolitu zapewnia niezawodno�� zasilania wi�kszo�ci system�w podtrzymywania napi�cia takich jak UPS czy systemy zasilania awaryjnego.

 Zastosowanie:

 Systemy alarmowe
 Systemy telewizji kablowej
 Wyposa�enie telekomunikacyjne
 Wyposa�enie kontolne
 Systemy ochrony
 Wyposa�enie medyczne
 UPS
 Zasilanie awaryjne
 Zabawki  (ciekawe w jakich gotowych zabawkach ten akumulator zosta� u�yty)

 Cechy og�lne:

 Bezobs�ugowy
 Konstrukcja uniemo�liwiaj�ca wyciek elektrolitu
 Hermetyczna obudowa
 Zaw�r bezpiecze�stwa zabezpieczaj�cy przed eksplozj�
 Wysoka jako�� i niezawodno��
 Wyj�tkowo silna w�a�ciwo�� odzyskiwania mocy
 Niska charakterystyka samoroz�adowania si�
 Mo�liwo�� instalacji w wielu pozycjach

 W�a�ciwo�ci:

 Napi�cie: 12V
 Pojemno��: 0,8 Ah
 �ywotno��: ok. 5 lat
 �adowanie(25 oC):
 u�ycie cykliczne: 7,2-7,5V(-15mV/oC), maksymalny pr�d: 0,3 A
 u�ycie ci�g�e: 6,8-6,9V(-10mV/oC)

 Wymiary i masa:

 Wysoko��: 62,3mm
 Szeroko��: 25mm
 D�ugo��: 96,5mm
 Waga: 0,38 kg

*/

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>
#include "ports.h"

static unsigned char wavedrive_lo_byte[4]={
	0b00000001,
	0b00000010,
	0b00000100,
	0b00001000
};

static unsigned char wavedrive_hi_byte[4]={
	0b00010000,
	0b00100000,
	0b01000000,
	0b10000000
};

#define FWD(p) p = (p+1)%4;
#define BCK(p) p = (p+3)%4;

int main(void)
{
	
	// nie u�ywany
	OUT_INIT_PORT(B)
	PORTB=0b000010;
	
	// sterowanie silniczkami
	OUT_INIT_PORT(D)
	PORTD=0b00010001;

	// nie u�ywane bity
	OUT_INIT_PORT(C)
	// przyciski
	IN_INIT(C,3)
	#define LEFT_TEST IN_TEST(C,3)
	IN_INIT(C,4)
	#define FWD_TEST IN_TEST(C,4)
	IN_INIT(C,5)
	#define RIGHT_TEST IN_TEST(C,5)
	
	int left=0, right=0;

	// _delay_ms oczekuje sta�ej jako argumentu  ( __builtin_avr_delay_cycles )
	int timing=1;
	// 12V, 602+119+347=1068g (rama+p�ytka+aku0.8)
	//#define BEAT if (timing) _delay_ms(50); else _delay_ms(500); PORTB^=0b00100010;
	//#define BEAT_PLUS if (timing) _delay_ms(20); else _delay_ms(0);
	
	// 24V, 602+119=721g (rama+p�ytka)
	//#define BEAT if (timing) _delay_ms(40); else _delay_ms(500); PORTB^=0b00100010;
	//#define BEAT_PLUS if (timing) _delay_ms(20); else _delay_ms(0);	
	// 10+2 obracaj� si� w powietrzu ale nie rusza
	// 20+2 rusza prawy silnik, lewy nie
	// 30+2 skr�t w lewo nie dzia�a i cofanie
	// 30+5 te� problemy ze skr�tem
	// 35+5 problem ze skr�tem w lewo czasem
	// 40+10 problem ze skr�tem w lewo czasem
	// 35+20 problem ze skr�tem w lewo i jazd� naprz�d
	// 40+20 wszystko dzia�a
	
	// widz�, �e za ka�d� zmian� taktowania: edytuj� plik, kompiluj�,
	// wy��czam zasilanie, wpinam goldpin 2x3, �aduj� program, wypinam goldpin 2x3, w��czam zasilanie
	// przyda�by si� program w kt�rym mo�na regulowa� taktowanie i kt�ry wy�wietla jakie ono jest
	// oraz rozwi�zanie sprz�towe, �eby nie wypina� ci�gle wytku programatora, mo�e jakie� odcinanie przeka�nikiem
	// ale program z regulacj� jest bardziej potrzebny, z trzema przyciskami jest wolne 9 pin�w
	// trzy przyciski daj� 7 sygna��w mo�liwych
	
	//// 24V, 602+119+232=953g (rama+p�ytka+balast o wadze baterii SLS XTRON 1450mAh 22.2V (woreczek fasoli))
	//#define BEAT if (timing) _delay_ms(20); else _delay_ms(500); PORTB^=0b00100010;
	//#define BEAT_PLUS if (timing) _delay_ms(20); else _delay_ms(0);
	// 40+20 je�dzi
	// 35+20 te� je�dzi ?
	// 20+20 nie je�dzi
	
	// program m�g�by regulowa� taktowanie w zale�no�ci od napi�ci� akumulatora 
	// startowanie i hamowanie mo�na zrobi� p�ynne, z przyspieszeniem
	// taktowanie half-step mo�e pomog�oby w rozruszaniu
	// sterownik z nikrokrokami podwy�szy�by pewnie wydajno��
	// czyli og�lnie widz�, �e stosowanie sterownik�w scalonych ma sens
	// bo pozwala osi�gna� wi�ksz� szybko�� obrot�w
	
	// ramka kt�r� z�o�y�em, jest przydatna tylko do nauki, bo za wolno je�dzi
	// jest g��wnie z duraluminium, ten sam kszta�t mo�na by zrobi� z aluminium
	
	//// 11.1V, 602+119+45g=766g (rama+plytka+bateria DUALSKY XP04003EX 11.1V)
	#define BEAT if (timing) _delay_ms(40); else _delay_ms(500); PORTB^=0b00100010;
	#define BEAT_PLUS if (timing) _delay_ms(20); else _delay_ms(0);
	// 20+20 dzia�a tylko skr�t w lewo
	// 35+20 dzia�aj� oba skr�ty
	// 40+20 je�dzi, do�o�enie telefonu 100g powoduje zatrzymywanie przy skr�cie w lewo
	
	while(1)
	{
		BEAT

		// piszcza�ka 	
		if (FWD_TEST&&LEFT_TEST&&RIGHT_TEST) {
			for (int i=0; i<50; i++) {
				PORTB^=0b000110;
				_delay_ms(1);
			}
		}
		
		if (FWD_TEST&&LEFT_TEST) {
			timing=0;
		}

		if (FWD_TEST&&RIGHT_TEST) {
			timing=1;
		}

		if (FWD_TEST) {
			FWD(left)
			FWD(right)
		}
		
		if (LEFT_TEST && (!RIGHT_TEST)) {
			BCK(left)
			FWD(right)
			BEAT_PLUS
		}
		
		if (RIGHT_TEST && (!LEFT_TEST)) {
			FWD(left)
			BCK(right)
			BEAT_PLUS
		}
		
		if (LEFT_TEST&&RIGHT_TEST) {
			BCK(left)
			BCK(right)
		}
		
		PORTD = wavedrive_hi_byte[left] | wavedrive_lo_byte[right];
	}
}

