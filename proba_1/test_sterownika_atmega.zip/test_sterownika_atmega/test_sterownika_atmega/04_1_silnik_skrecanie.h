
/* 04_1_silnik_skrecanie

SPRZ�T :

lpt1, severino, m8 #1, 16000000mhz
atmega8 ma porty 6,6,8 bitowe: B 0-5, C 0-5, D 0-7
�wiate�ko kontrolne jest na B5, sz�stym bicie portu B

FRAME_06, silnik lewy D7654, silnik prawy D3210
ULN na p�ytce stykowej, GND i 9V (12V) wzi�te z pin�w p�ytki
zasilanie z akumulatora wpi�te do gniazda p�ytki

Przyciski na C3 C4 C5

WYNIKI :

masa do przycisku nie mo�e by� z portu,
wi�c trzeba by�o zmieni� na C3 i C5, �eby da�o si� podpi�� mas� do wtyczki goldpin-m-5

taktowanie 50ms daje za s�aby moment, �eby lewy silnik ruszy� przy skr�cie,
bo lewy obraca si� CCW i ma s�abszy moment ni� prawy kt�ry obraca si� CW
jak w��czam oba to zaskakuj� i jedzie, ale dla 50ms i 12V skr�t jest tylko w lewo, prawym silnikiem
gdyby obraca�y si� oba, to mo�e moment tracia by�by mniejszy

potrzebuj� sterownik z 4 przyciskami, �eby zmienia� kierunek, ale lewy silnik jest s�abszy

zdolno�ci manewrowe przy obrocie k� tylko w jedn� stron� s� ograniczone,
po podjechaniu zbyt blisko przeszkody nie ma ju� mo�liwo�ci ruchu

taktowanie 100ms daje szarpane ruchy, na 75 te�, 55 nie rusza lewy, 
na 60 lewy buksuje na stole, czyli 65

potrzeba najprostsz� przetwornic� napi�cia
s�abej mocy mo�na zrobi� na ne555 i kondensatorach
max232 chyba jest za s�aby
- widz� �e to ca�e zagadnienie

doda�em na �rodkowym przycisku (pin C4) cofanie

*/ 

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>
#include "ports.h"

#define BEAT _delay_ms(65); PORTB^=0b00100000;

// sterowanie silnikami
unsigned char seq[4]={
	// lewy D7-4, prawy D3-0
	0b00010001,
	0b00100010,
	0b01000100,
	0b10001000
};

int main(void)
{
	
	// nie u�ywany
	OUT_INIT_PORT(B)
	
	// sterowanie silniczkami
	OUT_INIT_PORT(D)

	// // masa dla przycisk�w
    // OUT_INIT(C,0)
	// PORTC=0;
	// przyciski
	IN_INIT(C,3)
	#define LEFT_TEST IN_TEST(C,3)
	IN_INIT(C,5)
	#define RIGHT_TEST IN_TEST(C,5)
	IN_INIT(C,4)
	#define BACK_TEST IN_TEST(C,4)
	
	int seq_no=0;
	unsigned char mask;
	while(1)
	{
		if (BACK_TEST) {
			PORTD = seq[seq_no];
			seq_no = (seq_no+3)%4;  //dekrementacja modulo 4
			BEAT
			continue;
		}
        //else
		mask=0;
		if (LEFT_TEST)
			mask |= 0b11110000;
		if (RIGHT_TEST)
		    mask |= 0b00001111;
		PORTD = seq[seq_no] & mask;
		seq_no = (seq_no+1)%4;
		BEAT   	// spe�nia te� rol� debounce dla przycisk�w
	}	
}


