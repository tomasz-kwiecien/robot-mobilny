//wyb�r programu do kompilacji              //pami�� dane komentarz
//#include "01_test_diodami_i_rozruch.h"	//174 8 silniki na oddzielnych portach
//#include "02_prostszy_test_diodami.h"		//198 0 B��D, test port�w, mia�em u�y� przed poprawieniem 01	
//#include "03_sterowanie_uln.h"			//164 4 jazda naprz�d jednym portem, taktowanie 50ms, pr�dko�� 6,5cm/sek
//#include "04_1_silnik_skrecanie.h"		//252 4 maskowanie po��wek portu
//#include "05_2_silniki_obracanie.h"		//242 12 na sztywno trzy sekwencje steruj�ce dla trzech rodzaj�w ruchu
//#include "06_obroty_i_linia.h"			//258 16 dodanie czwartej na sztywno sekwencji ruchu
//#include "07_rozne_predkosci.h"			//306 16 zwolnienie taktowania przy skr�tach
//#include "08_poprawka_sterowania.h"		//312 16 B��D, chcia�em przypina� guziczki bez zwisaj�cego pinu, ale nie dzia�a�y tak
//#include "09_plynne_taktowanie_klasa.h"   //612 8 szkic niezale�nego taktowania, �eby zachowa� cykl przy zmianie kierunku
//#include "10_plynne_taktowanie_makra.h"	//442 8 niezale�ne taktowanie
//#include "11_zmienianie_taktowania.h"		//574 8 dwa taktowania, badanie zachowania
//#include "12_sprawdzanie_klawiszy.h"		//236 8 B��D, chcia�em dorobi� piszcza�k� piezo, ale co� nie dzia�a
//#include "13_kilka_taktowan.h"			//1018 12 10 taktowa�, prze�aczane tak samo jak w 11
//#include "14_wyswietlanie_panelem.h"      //1376 108 B��D, kod g��wny dobry, b��dy ukryte w makrach, NIE WIADOMO CZY B��D W P�YTCE CZY W KODZIE
//#include "15_test_panelu.h"				//220 0 B��D, sprawdzenie samych makr, ale b��dy dalej ukryte
//#include "16_test_wszystkich_portow.h"	//106 0 PORT BCD, miganie wszystkimi portami		
//#include "17_test_segmentow.h"			//106 0 PORT BC, miganie naprzemienne grupami segment�w
//#include "18_test_segmentow_2.h"			//276 0 PORT BC, cykliczne zapalanie, STWIERDZENIE SPRAWNOSCI P�YTKI
//#include "19_test_makr.h"					//232 96 PORT D, przypadkowe zapalanie wed�ug tablicy znak�w
//#include "20_test_makr_2.h"				//354 96 B��D, PORT BCD, nie dzia�a na portach BC 
//#include "21_test_makr_3.h"				//522 96 B��D, dzia�a tylko na porcie D, przypadkiem wpisa�em ~
#include "22_test_makr_4.h"				//410 96 B��D, dalej jest chyba jaki� b��d, odkry�em b��d w ports.h, wi�c za�o�y�em nowy projekt

/*

ca�y czas u�ywa�em ports.h, gdzie jest negacja logiczna zamiast bitowej
dzia�a�o, bo chyba mo�na ustawia� stan na wej�ciu poprzez pod��czanie albo opornika podci�gaj�cego
a w�a�nie to sprawia wpisywanie 1 i 0 do wej�cia
zamykam ten projekt, �eby nie straci� dokumentacji b��d�w

W plikach *.h s� kolejne warianty program�w. Ka�dy m�g�by by� w�a�ciwie oddzielnym projektem,
ale w AtmelStudio tworzenie nowego projektu d�ugo trwa, IDE bardzo wolno reaguje na tych opcjach.
Nie da si� tych program�w zapisywa� jako *.cpp, bo wtedy ca�o�� si� nie kompiluje.
Mo�na zrobi� jeden du�y plik *.cpp i w nim opcje #ifdef,
ale wtedy ca�o�� jest nieczytelna i zbyt d�uga.
Pocz�tkowo robi�em w taki spos�b.

Chcia�em, �eby w ka�dym pliku by� kompletny program.
Chodzi mi te� o to, �eby zachowywa�, nie modyfikowa� dzia�aj�cych wersji.
Wtedy, gdy co� dopisuj�, to �atwiej znajdowa� b��dy.

W tych programach wida� kolejno�� mojego rozumowania i rozwijania projektu.
To s� jakby kolejne wersje projektu, ale nie przechowywane za pomoc� �adnego CMS.
Jakby, bo te� na potrzeby testowania sprz�tu musz� robi� czasem ma�e programiki.
To jest tak po kolei pr�ba1 - b��d - prostsza_pr�ba2 - dobrze - powr�t_od_pr�by_1 - rozbudowa_pr�by_1 itd.
To jest jakby historia scrumu, historia wersji, nie wiem czy backlog scrumu.
Zapis do�wiadcze� i rozbudowy. W postaci serii program�w.

Widz� te� tak� og�ln� zasad� programowania, �e kod pisze si� tak,
�eby jak co� trzeba zmieni�, to �eby by�o to robione tylko w jednym miejscu.

Na przyk�adzie tego projektu widz�, �e jak kod jest zbyt rozstrzelony, zbyt redundantny z zapisie,
to �atwiej przeacza� bardzo d�ugo jak�� usterk�, i przy awarii szuka� jej gdzie indziej.
To jest taka obserwacja psychologiczna, psychologia postrzegania chyba jaka�.

*/



