
// 02_prostszy_test_diodami
// 198 0

// sprz�t:
// lpt1, severino, m8 #1, 16000000mhz
// atmega8 ma porty 6,6,8 bitowe: B 0-5, C 0-5, D 0-7
// �wiate�ko kontrolne jest na B5, sz�stym bicie portu B

// PORTD, golpin-8-mf-10cm, linijka LED 10, goldpin-10-f-zwora, 230om, zworka, jumper, 5V

// niepotrzebne, by� zawieszony port lpt, nie u�y�em
// jak port lpt si� zawiesi to pomaga tylko restart pc

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>

#define BEAT _delay_ms(300);PORTB^=0b00100000;

int main(void)
{
	
	DDRB=0b100000;
	PORTB=0b111111;	
	DDRC=0b00111100;
	PORTC=0b111111;
	DDRD=0b00001111;
	PORTD=0b11111111;
	while(1)
	{
		BEAT
		PORTD=0b11111110;
		BEAT
		PORTD=0b11111101;
		BEAT
		PORTD=0b11111011;
		BEAT
		PORTD=0b11110111;
	}
}

