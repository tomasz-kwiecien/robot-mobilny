
/* 17

SPRZ�T :
lpt1, severino, m8 #1, 16000000mhz

panel led podpi�cy z opornikami 1,5k, zapalane stanem niskim

WYNIK:
ab i cdefgh migaj� naprzemiennie

*/

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>

int main(void)
{
	DDRB=0xFF;
	DDRC=0xFF;
	PORTB=0xFF;
	PORTC=0x00;
	while(1)
	{
		PORTB^=0b00111111;
		PORTC^=0b00000011;
		_delay_ms(500);
	}
}
