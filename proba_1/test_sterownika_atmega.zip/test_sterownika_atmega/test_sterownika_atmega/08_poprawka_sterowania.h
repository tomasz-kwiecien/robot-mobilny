
/* 08_poprawka_sterowania

SPRZ�T :

lpt1, severino, m8 #1, 16000000mhz
atmega8 ma porty 6,6,8 bitowe: B 0-5, C 0-5, D 0-7
�wiate�ko kontrolne jest na B5, sz�stym bicie portu B

FRAME_06, silnik lewy D7654, silnik prawy D3210
ULN na p�ytce stykowej, GND i 9V (24V) wzi�te z pin�w p�ytki
zasilanie z akumulatora wpi�te do gniazda p�ytki

Przyciski na B5 B4 B3, lewo, naprz�d, prawo. B2 kontrolka.
Dodatkowe 12V z akumulatora podpi�tego na kablu i trzymanego w r�ce.
(moja zabawka z 1998 roku by�a plastikowa i baterie by�y w r�ce)

WYNIKI :

dioda zwiera permanentnie B5, trzeba do niej dorobi� zwork�

*/

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>
#include "ports.h"

#define BEAT _delay_ms(50); PORTB^=0b00000100;
#define ADD_DELAY _delay_ms(25);

// sterowanie silnikami
unsigned char seq_fwd[4]={
	// lewy D7-4, prawy D3-0
	0b00010001,
	0b00100010,
	0b01000100,
	0b10001000
};

unsigned char seq_lft[4]={
	// lewy D7-4, prawy D3-0
	0b10000001,
	0b01000010,
	0b00100100,
	0b00011000
};

unsigned char seq_rgt[4]={
	// lewy D7-4, prawy D3-0
	0b00011000,
	0b00100100,
	0b01000010,
	0b10000001
};

unsigned char seq_bck[4]={
	// lewy D7-4, prawy D3-0
	0b10001000,
	0b01000100,
	0b00100010,
	0b00010001
};

int main(void)
{
	
	// nie u�ywany
	OUT_INIT_PORT(C)
	
	// sterowanie silniczkami
	OUT_INIT_PORT(D)

    // kontrolka
	OUT_INIT(B,2)

	// przyciski
	IN_INIT(B,5)
	#define LEFT_TEST IN_TEST(B,5)
	IN_INIT(B,4)
	#define RIGHT_TEST IN_TEST(B,4)
	IN_INIT(B,3)
	#define FWD_TEST IN_TEST(B,3)
	
	int seq_no=0;
	while(1)
	{
		BEAT
		if ((FWD_TEST&&LEFT_TEST) || (FWD_TEST&&RIGHT_TEST))
			continue;
		if (FWD_TEST)
			PORTD = seq_fwd[seq_no];
		if (LEFT_TEST && (!RIGHT_TEST)) {
			PORTD = seq_lft[seq_no];
			ADD_DELAY
		}
		if (RIGHT_TEST && (!LEFT_TEST)) {
			PORTD = seq_rgt[seq_no];
			ADD_DELAY
		}
		if (LEFT_TEST&&RIGHT_TEST)
			PORTD = seq_bck[seq_no];
		seq_no = (seq_no+1)%4;
	}
}

