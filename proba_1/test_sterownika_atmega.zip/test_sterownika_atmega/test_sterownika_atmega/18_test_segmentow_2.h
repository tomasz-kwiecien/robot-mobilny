
/* 18

SPRZ�T :

lpt1, severino, m8 #1, 16000000mhz

panel led podpi�cy z opornikami 1,5k, zapalane stanem niskim
podpi�cie kabla od panelu: aC0 fC1 bB5 gB4 cB3 eB2 hB1 dB0, h-decimal point
h u�yte jako kontrolka

WYNIK:
kolejno zapalaj� si� i gasn� abcdefgh
wi�c p�ytka jest sprawna

b��d jest w makrach

*/

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>
#include "ports.h"

int main(void)
{
	DDRB=0xff;
	DDRC=0xff;
	PORTB=0xff;
	PORTC=0xff;
	
	while(1)
	{
		// aC0 bB5 cB3 dB0 eB2 fC1 gB4 hB1
		PORTC^=0b000001;
		_delay_ms(500);
		PORTB^=0b100000;
		_delay_ms(500);
		PORTB^=0b001000;
		_delay_ms(500);
		PORTB^=0b000001;
		_delay_ms(500);
		PORTB^=0b000100;
		_delay_ms(500);
		PORTC^=0b000010;
		_delay_ms(500);
		PORTB^=0b010000;
		_delay_ms(500);
		PORTB^=0b000010;
		_delay_ms(500);
		
	}
}
