
/* 01_test_diodami
174 8

SPRZ�T :
lpt1, severino, m8 #1, 16000000mhz
atmega8 ma porty 6,6,8 bitowe: B 0-5, C 0-5, D 0-7
�wiate�ko kontrolne jest na B5, sz�stym bicie portu B

PORTD, golpin-8-mf-10cm, linijka LED 10, goldpin-10-f-zwora, 230om, zworka, jumper, 5V

silnik lewy D0123, silnik prawy C5432, bokiem podpi�te napi�cie zasilaj�ce 12V

WYNIKI :
obraca�y si� w powietrzu, bez podpinania masy silnik�w, uzwojenia bra�y mas� z drugiego portu
nie pami�tem czy ruszy�o z miejsca, nie chc� ju� sprawdza�

*/

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>

#define BEAT _delay_ms(300);PORTB^=0b00100000;

// sterowanie silnikami
unsigned char seq[8]={
	// lewy, D0-3
	0b00000001,
	0b00000010,
	0b00000100,
	0b00001000,
	// prawy, C5-4
	0b100000,
	0b010000,
	0b001000,
	0b000100
};

int main(void)
{
	
	DDRB=0b100000;
	PORTB=0b111111;
	DDRC=0b00111100;
	PORTC=0b11111111;
	DDRD=0b00001111;
	PORTD=0b11111111;
	while(1)
	{
		for (int i=0; i<4; i++){
			BEAT
			PORTD=seq[i];
			PORTC=seq[i+4];
		}
	}
}

