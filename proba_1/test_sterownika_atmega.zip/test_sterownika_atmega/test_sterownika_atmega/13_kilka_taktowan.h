
/* 13_kilka_taktowan

SPRZ�T :

lpt1, severino, m8 #1, 16000000mhz
atmega8 ma porty 6,6,8 bitowe: B 0-5, C 0-5, D 0-7
�wiate�ko kontrolne jest na B5, sz�stym bicie portu B

FRAME_06, silnik lewy D7654, silnik prawy D3210
ULN na p�ytce stykowej, GND i 9V (12V) wzi�te z pin�w p�ytki
zasilanie z akumulatora wpi�te do gniazda p�ytki

Przyciski na C3 C4 C5, lewo, naprz�d, prawo
C3+C5 wstecz, C3+C4 taktowanie szybsze o 5+2, C4+C5 taktowanie wolniejsze o 5+2

pocz�tkowe taktowanie 50+20

piezo na B0-B1 nie przeszkadza w programowaniu  , lepsza by by�a cyferka

jedn� cyferk� mo�na bardzo du�o pokaza�, np cyklicznie wy�wietlaj�c litery tekstu
albo u�ywaj�c glif�w 7 segmentowych, na przyk�ad to wskazywanie kierunku

projekt cyferki do wpinania:
panel_led_7seg - oporniki_1k - koszulki - ta�ma_ide_9�y�_10cm - koszulki - goldpin_9pin_male
oporniki 1k daj� 5ma na port

WYNIKI :

musi by� op�nienie po klawiszach zmiany taktowania, inaczej ucieka

*/

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>
#include "ports.h"

static unsigned char wavedrive_lo_byte[4]={
	0b00000001,
	0b00000010,
	0b00000100,
	0b00001000
};

static unsigned char wavedrive_hi_byte[4]={
	0b00010000,
	0b00100000,
	0b01000000,
	0b10000000
};

#define FWD(p) p = (p+1)%4;
#define BCK(p) p = (p+3)%4;

// wiele taktowa�

#define INC_MOD(n,m) n=(n+1)%m;
#define DEC_MOD(n,m) n=(n+m-1)%m;

// _delay_ms oczekuje sta�ej jako argumentu  ( __builtin_avr_delay_cycles )
int timing=9;
int timing_max=10;
	
void beat()
{
	switch(timing) {
		case 0: _delay_ms(5); break;
		case 1: _delay_ms(10); break;
		case 2: _delay_ms(15); break;
		case 3: _delay_ms(20); break;
		case 4: _delay_ms(25); break;
		case 5: _delay_ms(30); break;
		case 6: _delay_ms(35); break;
		case 7: _delay_ms(40); break;
		case 8: _delay_ms(45); break;
		case 9: _delay_ms(50); break;
	}
	//aC0 fC1 bB5 gB4 cB3 eB2 hB1 dB0
	PORTB^=0b00111111;
	PORTC^=0b00000011;
}

void beat_plus()
{
	switch(timing)	{
		case 0: _delay_ms(2); break;
		case 1: _delay_ms(4); break;
		case 2: _delay_ms(6); break;
		case 3: _delay_ms(8); break;
		case 4: _delay_ms(10); break;
		case 5: _delay_ms(12); break;
		case 6: _delay_ms(14); break;
		case 7: _delay_ms(16); break;
		case 8: _delay_ms(18); break;
		case 9: _delay_ms(20); break;		
	}
}

int main(void)
{
	
	// nie u�ywany
	OUT_INIT_PORT(B)
	PORTB=0b000010;
	
	// sterowanie silniczkami
	OUT_INIT_PORT(D)
	PORTD=0b00010001;

	// nie u�ywane bity
	OUT_INIT_PORT(C)
	// przyciski
	IN_INIT(C,3)
	#define LEFT_TEST IN_TEST(C,3)
	IN_INIT(C,4)
	#define FWD_TEST IN_TEST(C,4)
	IN_INIT(C,5)
	#define RIGHT_TEST IN_TEST(C,5)
	OUT_INIT(C,0)
	OUT_INIT(C,1)
	// tu si� co� dzieje
	
	int left=0, right=0;
	
	while(1)
	{
		beat();

		if (FWD_TEST&&LEFT_TEST) {
			DEC_MOD(timing,timing_max)
			_delay_ms(500);
		}

		if (FWD_TEST&&RIGHT_TEST) {
			INC_MOD(timing,timing_max)
			_delay_ms(500);
		}

		if (FWD_TEST) {
			FWD(left)
			FWD(right)
		}
		
		if (LEFT_TEST && (!RIGHT_TEST)) {
			BCK(left)
			FWD(right)
			beat_plus();
		}
		
		if (RIGHT_TEST && (!LEFT_TEST)) {
			FWD(left)
			BCK(right)
			beat_plus();
		}
		
		if (LEFT_TEST&&RIGHT_TEST) {
			BCK(left)
			BCK(right)
		}
		
		PORTD = wavedrive_hi_byte[left] | wavedrive_lo_byte[right];
	}
}

