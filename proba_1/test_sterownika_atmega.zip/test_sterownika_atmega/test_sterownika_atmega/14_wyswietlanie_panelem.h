
/* 14_wyswietlanie_panelem
1376 108

SPRZ�T :

lpt1, severino, m8 #1, 16000000mhz
atmega8 ma porty 6,6,8 bitowe: B 0-5, C 0-5, D 0-7
�wiate�ko kontrolne jest na B5, sz�stym bicie portu B

FRAME_06, silnik lewy D7654, silnik prawy D3210
ULN na p�ytce stykowej, GND i 9V (12V) wzi�te z pin�w p�ytki
zasilanie z akumulatora wpi�te do gniazda p�ytki

Przyciski na C3 C4 C5, lewo, naprz�d, prawo
C3+C5 wstecz, C3+C4 taktowanie szybsze o 5+2, C4+C5 taktowanie wolniejsze o 5+2

pocz�tkowe taktowanie 50+20

panel led podpi�cy z opornikami 1,5k, zapalane stanem niskim
podpi�cie kabla od panelu: aC0 fC1 bB5 gB4 cB3 eB2 hB1 dB0, h-decimal point
h u�yte jako kontrolka

przyda�aby si� zworka do wy��czania kontrolki na p�ytce

WYNIKI :

sterowanie silnikami pocz�tkowo dzia�a
zachowanie nieokre�lone po naci�ni�ciu C4+C5
panel po w��czeniu pokazuje bc, po zaprogramowaniu pokazuje bcg

*/

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>
#include "ports.h"

//#include "ascii7seg.h"

//-------------------------------

//#ifndef ASCII7SEG_H_
//#define ASCII7SEG_H_

// przybli�enie znak�w ASCII na wy�wietlaczu 7 segmentowym
// znaki czytelne na led: 0123456789 ACEFGHJLOPSQUYZ bcdhnoru =",.^?
// reszta znak�w to graficzne przybli�enia
// znaki w tablicy s� od spacji, na razie tylko alfanumeryczne
// nie ma standardu dla takiego przybli�enia znak�w
const char led[]={
	0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,
	63,6,91,79,102,109,125,7,
	127,111,0,0,0,0,0,0,

	0,119,79,57,15,121,113,61,
	118,48,14,122,56,43,55,63,
	115,103,117,109,49,62,30,29,
	54,110,91,0,0,0,0,0,

	0,95,124,88,94,89,81,101,
	116,16,12,112,24,82,84,92,
	51,71,80,101,120,28,20,42,
	18,106,82,0,0,0,0,0
};

#define OUT_OFF(port,pin) PORT##port &= !(1<<pin);
#define OUT_ON(port,pin) PORT##port |= (1<<pin);

// dla paneli ze wsp�ln� katod�
#define LED_OUT_POS(v,ai,ao,bi,bo,ci,co,di,do,ei,eo,fi,fo,gi,go,hi,ho) \
{ int n=led[v-32]; \
	if (n & 0x00000001) OUT_ON(ai,ao) else OUT_OFF(ai,ao) \
	if (n & 0x00000010) OUT_ON(bi,bo) else OUT_OFF(bi,bo) \
	if (n & 0x00000100) OUT_ON(ci,co) else OUT_OFF(ci,co) \
	if (n & 0x00001000) OUT_ON(di,do) else OUT_OFF(di,do) \
	if (n & 0x00010000) OUT_ON(ei,eo) else OUT_OFF(ei,eo) \
	if (n & 0x00100000) OUT_ON(fi,fo) else OUT_OFF(fi,fo) \
	if (n & 0x01000000) OUT_ON(gi,go) else OUT_OFF(gi,go) \
	if (n & 0x10000000) OUT_ON(hi,ho) else OUT_OFF(hi,ho) \
}

// dla paneli ze wsp�ln� anod�
#define LED_OUT_NEG(v,ai,ao,bi,bo,ci,co,di,do,ei,eo,fi,fo,gi,go,hi,ho) \
{ int n=led[v-32]; \
	if (n & 0x00000001) OUT_OFF(ai,ao) else OUT_ON(ai,ao) \
	if (n & 0x00000010) OUT_OFF(bi,bo) else OUT_ON(bi,bo) \
	if (n & 0x00000100) OUT_OFF(ci,co) else OUT_ON(ci,co) \
	if (n & 0x00001000) OUT_OFF(di,do) else OUT_ON(di,do) \
	if (n & 0x00010000) OUT_OFF(ei,eo) else OUT_ON(ei,eo) \
	if (n & 0x00100000) OUT_OFF(fi,fo) else OUT_ON(fi,fo) \
	if (n & 0x01000000) OUT_OFF(gi,go) else OUT_ON(gi,go) \
	if (n & 0x10000000) OUT_OFF(hi,ho) else OUT_ON(hi,ho) \
}

// przyk�ad
// podpi�cie kabla od panelu: aC0 fC1 bB5 gB4 cB3 eB2 hB1 dB0, wsp�lna anoda
// konfiguracja makra: aC0 bB5 cB3 dB0 eB2 fC1 gB4 hB1
// #define LED_OUT(v) LED_OUT_NEG(v, C,0, B,5, B,3, B,0, B,2, C,1, B,4, B,1)

//#endif

//-------------------------------



// podpi�cie kabla od panelu: aC0 fC1 bB5 gB4 cB3 eB2 hB1 dB0, wsp�lna anoda
// konfiguracja makra: aC0 bB5 cB3 dB0 eB2 fC1 gB4 hB1
#define LED_OUT(v) LED_OUT_NEG(v, C,0, B,5, B,3, B,0, B,2, C,1, B,4, B,1)

static unsigned char wavedrive_lo_byte[4]={
	0b00000001,
	0b00000010,
	0b00000100,
	0b00001000
};

static unsigned char wavedrive_hi_byte[4]={
	0b00010000,
	0b00100000,
	0b01000000,
	0b10000000
};

#define FWD(p) p = (p+1)%4;
#define BCK(p) p = (p+3)%4;

// wiele taktowa�

#define INC_MOD(n,m) n=(n+1)%m;
#define DEC_MOD(n,m) n=(n+m-1)%m;

// _delay_ms oczekuje sta�ej jako argumentu  ( __builtin_avr_delay_cycles )
int timing=9;
int timing_max=10;

void beat()
{
	switch(timing) {
		case 0: _delay_ms(5); break;
		case 1: _delay_ms(10); break;
		case 2: _delay_ms(15); break;
		case 3: _delay_ms(20); break;
		case 4: _delay_ms(25); break;
		case 5: _delay_ms(30); break;
		case 6: _delay_ms(35); break;
		case 7: _delay_ms(40); break;
		case 8: _delay_ms(45); break;
		case 9: _delay_ms(50); break;
	}
	PORTB^=0b00100010;
}

void beat_plus()
{
	switch(timing)	{
		case 0: _delay_ms(2); break;
		case 1: _delay_ms(4); break;
		case 2: _delay_ms(6); break;
		case 3: _delay_ms(8); break;
		case 4: _delay_ms(10); break;
		case 5: _delay_ms(12); break;
		case 6: _delay_ms(14); break;
		case 7: _delay_ms(16); break;
		case 8: _delay_ms(18); break;
		case 9: _delay_ms(20); break;
	}
}

int main(void)
{
	
	// nie u�ywany
	OUT_INIT_PORT(B)
	PORTB=0b111111;
	
	// sterowanie silniczkami
	OUT_INIT_PORT(D)
	PORTD=0b00010001;

	// nie u�ywane bity
	OUT_INIT_PORT(C)
	OUT_ON(C,0)
	OUT_ON(C,1)
	// przyciski
	IN_INIT(C,3)
	#define LEFT_TEST IN_TEST(C,3)
	IN_INIT(C,4)
	#define FWD_TEST IN_TEST(C,4)
	IN_INIT(C,5)
	#define RIGHT_TEST IN_TEST(C,5)
	
	int left=0, right=0;
	
	while(1)
	{
		beat();

		if (FWD_TEST&&LEFT_TEST) {
			DEC_MOD(timing,timing_max)
			LED_OUT(timing+'0');
			_delay_ms(500);
		}

		if (FWD_TEST&&RIGHT_TEST) {
			INC_MOD(timing,timing_max)
			LED_OUT(timing+'0');
			_delay_ms(500);
		}

		if (FWD_TEST) {
			FWD(left)
			FWD(right)
		}
		
		if (LEFT_TEST && (!RIGHT_TEST)) {
			BCK(left)
			FWD(right)
			beat_plus();
		}
		
		if (RIGHT_TEST && (!LEFT_TEST)) {
			FWD(left)
			BCK(right)
			beat_plus();
		}
		
		if (LEFT_TEST&&RIGHT_TEST) {
			BCK(left)
			BCK(right)
		}
		
		PORTD = wavedrive_hi_byte[left] | wavedrive_lo_byte[right];
	}
}

