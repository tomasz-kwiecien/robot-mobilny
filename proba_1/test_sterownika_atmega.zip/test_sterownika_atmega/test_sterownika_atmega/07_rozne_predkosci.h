
/* 07_rozne_predkosi

SPRZ�T :

lpt1, severino, m8 #1, 16000000mhz
atmega8 ma porty 6,6,8 bitowe: B 0-5, C 0-5, D 0-7
�wiate�ko kontrolne jest na B5, sz�stym bicie portu B

FRAME_06, silnik lewy D7654, silnik prawy D3210
ULN na p�ytce stykowej, GND i 9V (12V) wzi�te z pin�w p�ytki
zasilanie z akumulatora wpi�te do gniazda p�ytki

Przyciski na C3 C4 C5, lewo, naprz�d, prawo
Mniejsze pr�dko�ci taktowania przy obrotach

Cofaj�c si� z '08_poprawka_sterowania'
sprawdzam tutaj konfiguracj� z wy�szym napi�ciem bez zwi�kszania obci��enia.

WYNIKI :

dla zasilania 12V:
50+10 (nie pami�tam ile by�o, nie zapisa�em)

dla zasilania 24V, wagi 1084g :
10+20 tylko obr�t w lewo
20+20 oba obroty
30+20 wszystko jedzie
25+0 nic nie jedzie, czasem skr�ty
30+5 zacina si� ruch do przodu
35+5 jedzie ale czasem nie zaskakuje od razu przy skr�tach
35+10 szybciej si� nie da

dla zasilania 12V, bez obci��enia :
166ppm, 6ms   21rusza 22rusza
200ppm, 5ms   21rusza ale czasem wibruje 22nie rusza
445ppm, 2.2ms  21nie 22nie

dla zasilania 12V, bez obci��enia :
125ppm, 8ms   21nie 22nie
15,17,20,30,40,50  21nie 22rusza ale czasem wibruje 
=> wy�adowa� si� akumulator 0.8Ah, prawy silniczek mia� odwrotnie wpi�ty kabelek

dla zasilania 12V, akumulator �adowany przez 1,5h :
6ms, 21 szarpany obr�t tylko CW, 22wibracje
10ms, oba kr�ca si� bez obci��enia, za ma�y moment �eby ruszy�o
gdyby rama by�a l�ejsza to mo�e by ruszy�o, szybciej by je�dzi�
40ms jedzie tylko w ty�, bo 22 obraca si� wtedy CW a 21 jest mocniejszy
50+10 czasem si� zacina przy skr�tach
50+20 optymalne

ROZWA�ANIA :

rama i silniczki z kablami: 602g
akumulator i mocowanie: 247g
p�ytki i kable: 119g

dorobi� kabelek przej�ciowy do p�ytki i kabelek przed�u�aj�cy do programatora
tak �eby roz��czanie by�o na wtyczce na nie na p�ytce
w sumie dwa kableki przed�u�aj�ce
a mo�na zrobi� uk�ad roz��czaj�cy na czas programowania jedynym przyciskiem

k�ka z mniejsz� powierzchni� styku mia�yby mo�e mniejsze opory ?
chyba nie, bo wtedy wi�kszy ci�ar jest na tej wi�kszej powierzchni

trzeba testowa� na najtrudniejszej dost�pnej powierzchni 
w moim przypadku na stole zamiast na pod�odze, na stole wi�ksze przyczepno��
zatrzymuje si� na gumce le��cej na pod�odze, to nie s� najlepsze k�ka

ULN grzeje si� troch�, jest na granicy wydajno�ci
OUTPUT CURRENT TO 500 mA 
OUTPUT VOLTAGE TO 50 V

					12V    24V
Rated Current/Phase 259mA 216mA

z tymi silniczkami nie jest tak, �e dwukrotne zwi�kszenie napi�cia
da dwukrotne zwi�kszenie si�y i szybko�ci

					12V    24V
Holding Torque 78.4mN�m 94.1mN�m
Max. Pull-out Pulse Rate 375pps 445pps   2,6ms 2,2ms
Max. Pull-in Pulse Rate 365pps 435pps   2,7ms 2,2ms

czyli zysk na zwi�kszeniu napi�cia jest 30%

tylko zmniejszenie ci�aru dla tych silniczk�w da�oby przyspieszenie
mo�na da� aluminium zamiast duraluminium (20z� ?)
oraz bateri� lipo zamiast �elowej (100z� ?) 
oraz mocniejsze silniczki, (100z� ?)
�adne odkrycie �e lepiej by� bogatym ni� biednym

=> do tej ramy takie silniczki s� za s�abe
przetwornica pewnie da mniej zysku ni� dodatkowy akumulator

spe�nia rol� edukacyjn�, nie musi by� szybki

*/

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>
#include "ports.h"

#define BEAT _delay_ms(50); PORTB^=0b00100000;
#define ADD_DELAY _delay_ms(20);

// sterowanie silnikami
unsigned char seq_fwd[4]={
	// lewy D7-4, prawy D3-0
	0b00010001,
	0b00100010,
	0b01000100,
	0b10001000
};

unsigned char seq_lft[4]={
	// lewy D7-4, prawy D3-0
	0b10000001,
	0b01000010,
	0b00100100,
	0b00011000
};

unsigned char seq_rgt[4]={
	// lewy D7-4, prawy D3-0
	0b00011000,
	0b00100100,
	0b01000010,
	0b10000001
};

unsigned char seq_bck[4]={
	// lewy D7-4, prawy D3-0
	0b10001000,
	0b01000100,
	0b00100010,
	0b00010001
};

int main(void)
{
	
	// nie u�ywany
	OUT_INIT_PORT(B)
	
	// sterowanie silniczkami
	OUT_INIT_PORT(D)

	// przyciski
	IN_INIT(C,3)
	#define LEFT_TEST IN_TEST(C,3)
	IN_INIT(C,5)
	#define RIGHT_TEST IN_TEST(C,5)
	IN_INIT(C,4)
	#define FWD_TEST IN_TEST(C,4)
	
	int seq_no=0;
	while(1)
	{
		BEAT
		if ((FWD_TEST&&LEFT_TEST) || (FWD_TEST&&RIGHT_TEST)) 
			continue;
		if (FWD_TEST) 
			PORTD = seq_fwd[seq_no];
		if (LEFT_TEST && (!RIGHT_TEST)) {
			PORTD = seq_lft[seq_no];
			ADD_DELAY
		}
		if (RIGHT_TEST && (!LEFT_TEST)) {
			PORTD = seq_rgt[seq_no];
			ADD_DELAY
		}
		if (LEFT_TEST&&RIGHT_TEST) 
			PORTD = seq_bck[seq_no];
		seq_no = (seq_no+1)%4;
	}
}

