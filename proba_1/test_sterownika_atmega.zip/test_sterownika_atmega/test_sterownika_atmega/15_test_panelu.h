
/* 15

SPRZ�T :

lpt1, severino, m8 #1, 16000000mhz

panel led podpi�cy z opornikami 1,5k, zapalane stanem niskim
podpi�cie kabla od panelu: aC0 fC1 bB5 gB4 cB3 eB2 hB1 dB0, h-decimal point
h u�yte jako kontrolka

WYNIK:
zapala si� tylko segment a i b
wydaje si�, �e wp�yw mia�o usuni�cie IN_INIT(C,_)

*/

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>
#include "ports.h"

// przybli�enie znak�w ASCII na wy�wietlaczu 7 segmentowym
// znaki czytelne na led: 0123456789 ACEFGHJLOPSQUYZ bcdhnoru =",.^?
// reszta znak�w to graficzne przybli�enia
// znaki w tablicy s� od spacji, na razie tylko alfanumeryczne
// nie ma standardu dla takiego przybli�enia znak�w
const char led[]={
	0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,
	63,6,91,79,102,109,125,7,
	127,111,0,0,0,0,0,0,

	0,119,79,57,15,121,113,61,
	118,48,14,122,56,43,55,63,
	115,103,117,109,49,62,30,29,
	54,110,91,0,0,0,0,0,

	0,95,124,88,94,89,81,101,
	116,16,12,112,24,82,84,92,
	51,71,80,101,120,28,20,42,
	18,106,82,0,0,0,0,0
};

#define OUT_OFF(port,pin) PORT##port &= !(1<<pin);
#define OUT_ON(port,pin) PORT##port |= (1<<pin);

// dla paneli ze wsp�ln� katod�
#define LED_OUT_POS(v,ai,ao,bi,bo,ci,co,di,do,ei,eo,fi,fo,gi,go,hi,ho) \
{ int n=led[v-32]; \
	if (n & 0x00000001) OUT_ON(ai,ao) else OUT_OFF(ai,ao) \
	if (n & 0x00000010) OUT_ON(bi,bo) else OUT_OFF(bi,bo) \
	if (n & 0x00000100) OUT_ON(ci,co) else OUT_OFF(ci,co) \
	if (n & 0x00001000) OUT_ON(di,do) else OUT_OFF(di,do) \
	if (n & 0x00010000) OUT_ON(ei,eo) else OUT_OFF(ei,eo) \
	if (n & 0x00100000) OUT_ON(fi,fo) else OUT_OFF(fi,fo) \
	if (n & 0x01000000) OUT_ON(gi,go) else OUT_OFF(gi,go) \
	if (n & 0x10000000) OUT_ON(hi,ho) else OUT_OFF(hi,ho) \
}

// dla paneli ze wsp�ln� anod�
#define LED_OUT_NEG(v,ai,ao,bi,bo,ci,co,di,do,ei,eo,fi,fo,gi,go,hi,ho) \
{ int n=led[v-32]; \
	if (n & 0x00000001) OUT_OFF(ai,ao) else OUT_ON(ai,ao) \
	if (n & 0x00000010) OUT_OFF(bi,bo) else OUT_ON(bi,bo) \
	if (n & 0x00000100) OUT_OFF(ci,co) else OUT_ON(ci,co) \
	if (n & 0x00001000) OUT_OFF(di,do) else OUT_ON(di,do) \
	if (n & 0x00010000) OUT_OFF(ei,eo) else OUT_ON(ei,eo) \
	if (n & 0x00100000) OUT_OFF(fi,fo) else OUT_ON(fi,fo) \
	if (n & 0x01000000) OUT_OFF(gi,go) else OUT_ON(gi,go) \
	if (n & 0x10000000) OUT_OFF(hi,ho) else OUT_ON(hi,ho) \
}

// podpi�cie kabla od panelu: aC0 fC1 bB5 gB4 cB3 eB2 hB1 dB0, wsp�lna anoda
// konfiguracja makra: aC0 bB5 cB3 dB0 eB2 fC1 gB4 hB1
#define LED_OUT(v) LED_OUT_NEG(v, C,0, B,5, B,3, B,0, B,2, C,1, B,4, B,1)



int main(void)
{
	OUT_INIT_PORT(B)
	OUT_INIT_PORT(C)
	
	while(1)
	{
		LED_OUT('A')
		_delay_ms(500);
		LED_OUT('B')
		_delay_ms(500);
		LED_OUT('C')
		_delay_ms(500);
		LED_OUT('D')
		_delay_ms(500);
	}
}
