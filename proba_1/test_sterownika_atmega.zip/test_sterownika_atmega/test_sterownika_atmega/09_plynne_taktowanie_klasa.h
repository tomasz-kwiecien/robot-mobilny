
/* 09_plynne_taktowanie_klasa

SPRZ�T :

lpt1, severino, m8 #1, 16000000mhz
atmega8 ma porty 6,6,8 bitowe: B 0-5, C 0-5, D 0-7
�wiate�ko kontrolne jest na B5, sz�stym bicie portu B

FRAME_06, silnik lewy D7654, silnik prawy D3210
ULN na p�ytce stykowej, GND i 9V (12V) wzi�te z pin�w p�ytki
zasilanie z akumulatora wpi�te do gniazda p�ytki

Przyciski na C3 C4 C5, lewo, naprz�d, prawo
Pami�tanie fazy silnika

WYNIKI :

pocz�tkowe wachni�cie bierze si� z bezw�adno�ci pojazdu
gdy silnik si� rozkr�ci, porusza si� p�ynnie

czy mo�na p�ynnie ruszy� takim silnikiem ?
zwi�kszaj�c taktowanie ?
lego ma opcj� regulacji przyspieszenia

ROZWA�ANIA :

co jest szybsze ? klasa i metody czy struktura i funkcje
chyba to samo bo jest przekazywanie wska�nika
albo makrami zrobi� co�, co by nie przekazywa�o wska�nika

#define FWD_STEP(motor)

dwie 'eleganckie' opcje, klasa albo makra
do mikrokontrolera potrzebne s� makra
('eleganckie' w sensie wygodne do u�ycia i czytelne)

*/

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>
#include "ports.h"

#define BEAT _delay_ms(50); PORTB^=0b00100000;
#define ADD_DELAY _delay_ms(20);

static unsigned char seq[4]={
	0b00000001,
	0b00000010,
	0b00000100,
	0b00001000
};

// na razie robi� to tak, �eby ogarn�� temat, potem b�d� optymalizowa�
class unipolar_wavedrive {
	public:
	int phase;
	unipolar_wavedrive(){
		phase=0;
	}
	void step_fwd()
	{
		phase = (phase+1)%4;
	}
	void step_bck()
	{
		phase = (phase+3)%4;
	}
	unsigned char get_seq() {
		return seq[phase];
	}
};

unipolar_wavedrive left,right;

int main(void)
{
	
	// nie u�ywany
	OUT_INIT_PORT(B)
	
	// sterowanie silniczkami
	OUT_INIT_PORT(D)

	// przyciski
	IN_INIT(C,3)
	#define LEFT_TEST IN_TEST(C,3)
	IN_INIT(C,5)
	#define RIGHT_TEST IN_TEST(C,5)
	IN_INIT(C,4)
	#define FWD_TEST IN_TEST(C,4)
	
	while(1)
	{
		BEAT
		
		if ((FWD_TEST&&LEFT_TEST) || (FWD_TEST&&RIGHT_TEST)) 
			continue;
		if (FWD_TEST) {
			left.step_fwd();
			right.step_fwd();
		}
		if (LEFT_TEST && (!RIGHT_TEST)) {
			left.step_bck();
			right.step_fwd();
			ADD_DELAY
		}
		if (RIGHT_TEST && (!LEFT_TEST)) {
			left.step_fwd();
			right.step_bck();
			ADD_DELAY
		}
		if (LEFT_TEST&&RIGHT_TEST) {
			left.step_bck();
			right.step_bck();
		}
			
		PORTD = (left.get_seq()<<4) | right.get_seq();	
	}
}

