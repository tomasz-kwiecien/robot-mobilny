
/* 21

SPRZ�T :

lpt1, severino, m8 #1, 16000000mhz

panel led podpi�cy z opornikami 1,5k, zapalane stanem niskim
synga� na porcie D, proste przepisywanie sekwencji segment�w
kabel wpi�ty do aC0 fC1 bB5 gB4 cB3 eB2 hB1 dB0

WYNIK:
na C0 C1 B5 B4 B3 B2 B1 B0 jakby si� co� nie wymazywa�o
na D7 D6 D5 D4 D3 D2 D1 D0 dzia�a

*/

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>
#include "ports.h"
// przybli�enie znak�w ASCII na wy�wietlaczu 7 segmentowym
// znaki czytelne na led: 0123456789 ACEFGHJLOPSQUYZ bcdhnoru =",.^?
// reszta znak�w to graficzne przybli�enia
// znaki w tablicy s� od spacji, na razie tylko alfanumeryczne
// nie ma standardu dla takiego przybli�enia znak�w
const char led[]={
	0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,
	63,6,91,79,102,109,125,7,
	127,111,0,0,0,0,0,0,

	0,119,79,57,15,121,113,61,
	118,48,14,122,56,43,55,63,
	115,103,117,109,49,62,30,29,
	54,110,91,0,0,0,0,0,

	0,95,124,88,94,89,81,101,
	116,16,12,112,24,82,84,92,
	51,71,80,101,120,28,20,42,
	18,106,82,0,0,0,0,0
};

#define OUT_OFF2(port,pin) PORT##port &= !(0b000001<<pin);
#define OUT_ON2(port,pin) PORT##port |= (0b000001<<pin);

#define TEST_BIT(b,i) ((b) & (1<<(i)))
#define SET_SEGMENT(code,bit,port,pin) if (TEST_BIT(code,bit)) OUT_ON2(port,pin) else OUT_OFF2(port,pin)

int main(void)
{
	DDRD=0xff;
	PORTD=0xff;
	DDRB=0xff;
	PORTB=0xff;
	DDRC=0xff;
	PORTC=0xff;
	
	int l,w,beat;  //led, wynik
	beat=0;
	
	while(1)
	{
		for (int c='0'; c<='z';c++){
			
			// ---------
			// sygna� testowy
			l=led[c-32];
			w=0xff;
			
			// kolejno�� w kablu: com a f b g c e h d
			// wpi�cie kabla do portu D: a7 f6 b5 g4 c3 e2 h1 d0
			// numeracja segment�w w kodzie z tablicy led: a0 b1 c2 d3 e4 f5 g6 h7
			// zmiana po�o�enia bit�w: 0>7 1>5 2>3 3>0 4>2 5>6 6>4 7>1
			if (l & (1<<0)) w&=(~(1<<7));
			if (l & (1<<1)) w&=(~(1<<5));
			if (l & (1<<2)) w&=(~(1<<3));
			if (l & (1<<3)) w&=(~(1<<0));
			if (l & (1<<4)) w&=(~(1<<2));
			if (l & (1<<5)) w&=(~(1<<6));
			if (l & (1<<6)) w&=(~(1<<4));
			if (beat) w&=(~(1<<1)); beat=~beat;
						
			PORTD=w;
			
			// ----------
			// sygna� docelowy aC0 bB5 cB3 dB0 eB2 fC1 gB4 hB1
			// 0-C0 1-B5 2-B3 3-B0 4-B2 5-C1 6-B4 7-B1
			l=~led[c-32];
			
			PORTB=0xff;
			PORTC=0xff;
			
			SET_SEGMENT(l,0,C,0)
			_delay_ms(10);
			SET_SEGMENT(l,1,B,5)
			_delay_ms(10);
			SET_SEGMENT(l,2,B,3)
			_delay_ms(10);
			SET_SEGMENT(l,3,B,0)
			_delay_ms(10);
			SET_SEGMENT(l,4,B,2)
			_delay_ms(10);
			SET_SEGMENT(l,5,C,1)
			_delay_ms(10);
			SET_SEGMENT(l,6,B,4)
			_delay_ms(10);
			SET_SEGMENT(l,7,B,1)
			_delay_ms(10);
			
			_delay_ms(200);
		}
	}
}
