
/* 11_zmienianie_taktowania

SPRZ�T :

lpt1, severino, m8 #1, 16000000mhz
atmega8 ma porty 6,6,8 bitowe: B 0-5, C 0-5, D 0-7
�wiate�ko kontrolne jest na B5, sz�stym bicie portu B

FRAME_06, silnik lewy D7654, silnik prawy D3210
ULN na p�ytce stykowej, GND i 9V (12V) wzi�te z pin�w p�ytki
zasilanie z akumulatora wpi�te do gniazda p�ytki

Przyciski na C3 C4 C5, lewo, naprz�d, prawo
C3+C5 wstecz, C3+C4 taktowanie szybsze, C4+C5 taktowanie wolniejsze

WYNIKI :
dzia�a jakby by� ca�y czas wci�ni�ty LEFT
po wykomentowaniu wszystkiego poza if (FWD) nie reaguje na nic
nie jest to b��d sprz�towy by program 11 dzia�a normalnie

*/

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>
#include "ports.h"

static unsigned char wavedrive_lo_byte[4]={
	0b00000001,
	0b00000010,
	0b00000100,
	0b00001000
};

static unsigned char wavedrive_hi_byte[4]={
	0b00010000,
	0b00100000,
	0b01000000,
	0b10000000
};

#define FWD(p) p = (p+1)%4;
#define BCK(p) p = (p+3)%4;

int main(void)
{
	
	// nie u�ywany
	OUT_INIT_PORT(B)
	PORTB=0b000010;
	
	// sterowanie silniczkami
	OUT_INIT_PORT(D)
	PORTD=0b00010001;

	// nie u�ywane bity
	OUT_INIT_PORT(C)
	IN_INIT(C,3)
	IN_INIT(C,4)
	IN_INIT(C,5)
	#define KEYS (PORTC & 0b00001110)
	#define LEFT      0b00001000
	#define FORWARD	  0b00000100
	#define RIGHT     0b00000010
	
	int left=0, right=0;

	// _delay_ms oczekuje sta�ej jako argumentu  ( __builtin_avr_delay_cycles )
	int timing=0;
	#define BEAT if (timing) _delay_ms(50); else _delay_ms(500); PORTB^=0b00100000;
	#define BEAT_PLUS if (timing) _delay_ms(20); else _delay_ms(0);
	
	while(1)
	{
		BEAT

		// piszcza�ka - nie dzia�a		
		//if (KEYS == (LEFT | RIGHT | FORWARD)) {
			//for (int i=0; i<50; i++) {
				//PORTB^=0b000110;
				//_delay_ms(1);
			//}
		//}
		//
		//if (KEYS == (FORWARD | LEFT)) {
			//timing=0;
		//}
//
		//if (KEYS == (FORWARD | RIGHT)) {
			//timing=1;
		//}

		if (KEYS == FORWARD) {
			FWD(left)
			FWD(right)
		}
		
		//if (KEYS == LEFT) {
			//BCK(left)
			//FWD(right)
			//BEAT_PLUS
		//}
		//
		//if (KEYS == RIGHT) {
			//FWD(left)
			//BCK(right)
			//BEAT_PLUS
		//}
		//
		//if (KEYS == (LEFT | RIGHT)) {
			//BCK(left)
			//BCK(right)
		//}
		
		PORTD = wavedrive_hi_byte[left] | wavedrive_lo_byte[right];
	}
}

