
/* 10_plynne_taktowanie_makra

SPRZ�T :

lpt1, severino, m8 #1, 16000000mhz
atmega8 ma porty 6,6,8 bitowe: B 0-5, C 0-5, D 0-7
�wiate�ko kontrolne jest na B5, sz�stym bicie portu B

FRAME_06 silnik lewy D7654, silnik prawy D3210
ULN na p�ytce stykowej, GND i 9V (12V) wzi�te z pin�w p�ytki
zasilanie z akumulatora wpi�te do gniazda p�ytki

Przyciski na C3 C4 C5, lewo, naprz�d, prawo
Pami�tanie fazy silnika

WYNIKI :

pomy�kowe  BCK(left)  FWD(right) bez ADD_DELAY powoduje buksowanie lewego ko�a

jest kopni�cie po w��czeniu zasilania, silniki ustawiaj� si� 

ROZWA�ANIA :

cena materia��w oko�o 100z�  :
2 silniczki Mitsumi M42SP-5   40z�
akumulator XTREME 82-208# 0.8Ah 12V   20z�
[akumulator Dualsky 400mAh 35C/5C 11.1V   37z�]
atmega8a  12z�
p�ytka do wytrawiania, materia�y, cz�ci, �rubki, k�ka 20z�
uln2804 2z�
goldpiny i kable 4z�
ramka aluminiowa 5z� (materia� trzeba kupi� za 20z�)
p�ytka stykowa 5z�

przypuszczalny czas pracy z obecnym do�wiadczeniem : 2-3 dni

wyceniaj�c swoj� prac� na 12z� (minimalna stawka godzinowa od 2017)
2*8 godzin za��my, to praca jest warta 192z�
co daje ca�kowit� cen� oko�o 300z�
(wytrawianie p�ytki, lutowanie cz�ci, pi�owanie, wiercenie, szlifowanie, lutowanie, klejenie, skr�canie, zaprogramowanie)

za 300 z� przemys� wyprodukuje drona lataj�cego
gdyby to robi� jako� szybciej, zmechanizowa� produkcj�
to mo�na by obni�y� koszt pracy

przemys� wymaga inwestycji w maszyny do obr�bki
w amatorskiej konstrukcji minimalny koszt wykonania mo�e przewy�sza� warto�� cz�ci

za�o�eniem jest wykonanie konstrukcji z og�lnie dost�pnych cz�ci,
u�ywaj�c metod dost�pnych amatorowi
chodzi o to, �e kto� to mo�e potem zmodyfikowa�, rozbudowa�, zrobi� sam

*/

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>
#include "ports.h"

#define BEAT _delay_ms(50); PORTB^=0b00100000;
#define ADD_DELAY _delay_ms(20);

static unsigned char wavedrive_lo_byte[4]={
	0b00000001,
	0b00000010,
	0b00000100,
	0b00001000
};

static unsigned char wavedrive_hi_byte[4]={
	0b00010000,
	0b00100000,
	0b01000000,
	0b10000000
};

#define FWD(p) p = (p+1)%4;
#define BCK(p) p = (p+3)%4;

int main(void)
{
	
	// nie u�ywany
	OUT_INIT_PORT(B)
	
	// sterowanie silniczkami
	OUT_INIT_PORT(D)
	PORTD=0b00010001;

	// nie u�ywane bity
	OUT_INIT_PORT(C)
	// przyciski
	IN_INIT(C,3)
	#define LEFT_TEST IN_TEST(C,3)
	IN_INIT(C,5)
	#define RIGHT_TEST IN_TEST(C,5)
	IN_INIT(C,4)
	#define FWD_TEST IN_TEST(C,4)
	
	int left=0, right=0;
	
	while(1)
	{
		BEAT
		
		if ((FWD_TEST&&LEFT_TEST) || (FWD_TEST&&RIGHT_TEST))
			continue;
			
		if (FWD_TEST) {
			FWD(left)
			FWD(right)
		}
		
		if (LEFT_TEST && (!RIGHT_TEST)) {
			BCK(left)
			FWD(right)
			ADD_DELAY
		}
		
		if (RIGHT_TEST && (!LEFT_TEST)) {
			FWD(left)
			BCK(right)
			ADD_DELAY
		}
		
		if (LEFT_TEST&&RIGHT_TEST) {
			BCK(left)
			BCK(right)
		}
		
		PORTD = wavedrive_hi_byte[left] | wavedrive_lo_byte[right];
	}
}

