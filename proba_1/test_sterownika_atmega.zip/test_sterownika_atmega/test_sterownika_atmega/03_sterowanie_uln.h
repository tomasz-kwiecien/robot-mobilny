
/* 03_sterowanie_uln
164 4

SPRZ�T :

lpt1, severino, m8 #1, 16000000mhz
atmega8 ma porty 6,6,8 bitowe: B 0-5, C 0-5, D 0-7
�wiate�ko kontrolne jest na B5, sz�stym bicie portu B

FRAME_06, silnik lewy D7654, silnik prawy D3210
ULN na p�ytce stykowej, GND i 9V (12V) wzi�te z pin�w p�ytki
wtyczka z akumulatora wpi�ta do gniazda p�ytki

do programowania trzeba wy��czy� akumulator i od��czy� vcc od uk�adu uln

WYNIKI :

praktycznie minimalne op�nienie to 50ms (mo�e z jakim� zapasem, ale to ju� bez r�nicy)
dla 40 za ma�y moment �eby ruszy�o, ale jeszcze si� toczy z popchni�ciem
dla 30 ju� si� nie toczy 
dla 10 rusza bez obci��enia
dla 5 nie rusza bez obci��enia

odwr�cenie wtyczki D76543210 -> D01234567 powoduje obroty obu silniczk�w w przeciwn� stron�
sekwencja jest symetryczna, wi�c powoduje to odwr�cenie sekwencji dla obu silnik�w

ca�o�� wa�y 1071g, do�o�enie akumulatora 1410g powoduje �e ju� nie rusza
jak si� do��czy szeregowo ten akumulator, daj�c 24V, to jedzie
przy 24V, zwi�kszenia taktowania do 10ms powoduje, �e znowu nie rusza

przy taktowaniu 50ms, 250cm przeje�d�a w 38 sekund, czyli pr�dko�� 6,5 cm/sek
gdyby da�o si� zej�� z taktowaniem do 10ms to by by�o 60cm/sek

ROZWA�ANIA :

mo�e podwy�szenie napi�cia daje mo�liwo�� zwi�kszenia taktowania
(chyba tak, co� pami�tam, �e napi�cie daje szybko��, nat�enie si�� statyczn�
na pewno tak jest dla silnika szczotkowego, ale nat�enie jest wypadkow� napi�cia,
chyba maksymalne mo�liwe do pobrania nat�enie przy ustalonym napi�ciu wp�ywa na si��)
holding torque : 78.4mN�m, 
pull-out torque : 27.6mN�m/200pps,   (5 ms)
pull-in torque : 26.5mN�m/200pps (12V DC).

25 miliniuton�w = 0.025 niutona, niuton = 10 dkg, 0.025*0.01kg=0.00025kg, jedna czwarta grama ?

mo�e zastosowanie L297 umo�liwi zwi�kszenie takowania 

Ciekawe jaki pr�d p�ynie, na ile wystarczy akumulator.

wida� proporcjonaln� zale�no�� fizyczna mi�dzy momentem silnika a napi�ciem
zwi�kszenie napi�cia dwukrotnie i zwi�kszenie masy pojazdu dwukrotnie (w��ciwie to wi�cej)
powoduje, �e graniczne taktowanie jest takie samo

to by mo�e znaczy�o, �e dwukrotne zwi�kszenie zasilania
da mo�liwo�� zwi�kszenia taktowania tylko dwukrotnie, czyli 25 ms, czyli 30 cm/sek

jak wjedzie w zag��bienie pod�ogi to staje, tak dzia�aj� cztery k�ka
ale jak s� cztery to mo�na na ramce ustawi� dodatkowy ci�ar

*/

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>

#define BEAT _delay_ms(40); PORTB^=0b00100000;

// sterowanie silnikami
unsigned char seq[4]={
	// lewy D7-4, prawy D3-0
	0b00010001,
	0b00100010,
	0b01000100,
	0b10001000
};

int main(void)
{
	
	DDRB  = 0b100000;
	PORTB = 0b111111;
	DDRC  = 0b00000000;
	PORTC = 0b11111111;
	DDRD  = 0b11111111;
	PORTD = 0b00010001;
	while(1)
	{
		for (int i=0; i<4; i++){
			PORTD=seq[i];
			BEAT
		}
	}
}


