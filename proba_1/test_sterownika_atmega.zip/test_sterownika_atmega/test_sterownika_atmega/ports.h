/*
 * ports.h
 *
 * Created: 2015-10-23 14:45:49
 *  Author: Tomasz Kwiecie�
 * wersja 1.0, z b��dem negacji logicznej zamiast bitowej, ! zamiast ~
 * z tym b��dem dzia�a�y dwa projekty sterownik�w
 */ 


#ifndef PORTS_H_
#define PORTS_H_

// inicjowanie pojedynczych bit�w jako wej�cie lub wyj�cie
#define OUT_INIT(port,pin) DDR##port |= 1<<pin; PORT##port &= !(1<<pin);
#define OUT_OFF(port,pin) PORT##port &= !(1<<pin);
#define OUT_ON(port,pin) PORT##port |= (1<<pin);
#define OUT_XOR(port,pin) PORT##port ^= (1<<pin);
#define IN_INIT(port,pin) DDR##port &= !(1<<pin); PORT##port |= 1<<pin;
#define IN_TEST(port,pin) (!(PIN##port & (1<<pin)))
// inicjowanie ca�ego portu jako wej�cie lub wyj�cie
#define OUT_INIT_PORT(port) DDR##port = 0xFF; PORT##port = 0x00;
#define IN_INIT_PORT(port) DDR##port = 0x00; PORT##port = 0xFF;

#endif /* PORTS_H_ */