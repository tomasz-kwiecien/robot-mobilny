
#include "00 informacje o projekcie.h"

#ifdef ITERACJA_01

// tiny2313, 4MHz
// Kod skopiowany [link ?]
// Szybko�� mierzy�em tarcz� stroboskopow� o�wietlan� �wiat�em 120Hz z sieci.

#define F_CPU 4000000UL
#include <avr/io.h>
#include <util/delay.h>

int main(void)
{
	// w��czenie pull-up
	PORTB = _BV(PB0) | _BV(PB1) ;
	
	DDRB   |= (1 << PB2);                   // PWM output on PB2
	TCCR0A = (1 << COM0A1) | (1 << WGM00);  // phase correct PWM mode
	OCR0A  = 0x00;                          // initial PWM pulse width
	
	TCCR0B = (1 << CS01);   // clock source = CLK/8, start PWM
	
	while(1)
	{
		// odczyt klawiszy co 1/100 sekundy
		_delay_ms(10);
		
		if ( PINB & 0x01 )
		if (OCR0A >0)
		OCR0A  = OCR0A-1;
		if ( PINB & 0x02 )
		if (OCR0A <255)
		OCR0A  = OCR0A+1;
		
		PORTB=0;
	}
}

#endif