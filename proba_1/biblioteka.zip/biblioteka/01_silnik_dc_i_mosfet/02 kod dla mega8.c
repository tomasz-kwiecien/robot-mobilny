
#include "00 informacje o projekcie.h"

#ifdef ITERACJA_02

// Przeniesienie kodu z attiny2313 do p�ytki z amtega8a.
// Tu 

#include <avr/io.h>

int main(void)
{
	while(1)
	{
		
	}
}

#endif

