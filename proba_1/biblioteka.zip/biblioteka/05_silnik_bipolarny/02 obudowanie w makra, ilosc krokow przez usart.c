
#include "00 informacje o projekcie.h"

#ifdef ITERACJA_02

// sterowanie krokowe poprzez przeka�niki do zmiany kierunku pr�du
// sekwencja tak jak naciska�em przyciski dla przeka�nik�w
// niepraktyczne bo przeka�niki maj� oko�o miliona zadzia�a�
// i ograniczaj� pr�dko�� i wprowadzaj� asymetri� dzia�ania
// przeka�niki DS2Y-S-DC5V, silniczek: m35sp-11hpk, mosfet: FS1-SM 16A
// silniczek wydaje si� mie� oko�o 100 krok�w na obr�t, w katalogu krok 3.75 stopni
// (by� b��d w drugim ifie, zerowane preesd_fwd, ale nie by�o tego wida�)
//				Program Memory Usage 	:	696 bytes   8,5 % Full
//				Data Memory Usage 		:	30 bytes   2,9 % Full


#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>
#include <stdlib.h>

// header port_macros.h

#define OUT_INIT(port,pin) DDR##port |= 1<<pin; PORT##port &= !(1<<pin);
#define OUT_OFF(port,pin) PORT##port &= !(1<<pin);
#define OUT_ON(port,pin) PORT##port |= (1<<pin);

#define IN_INIT(port,pin) DDR##port &= !(1<<pin); PORT##port |= 1<<pin;
#define IN_TEST(port,pin) (!(PIN##port & (1<<pin)))

// interfejs p�ytki, wej�cia: C5 C2 C1 C0, wyj�cia: D5 D6 D7 B0

// konfiguracja, wyj�cia: AP AM BP BM, wej�cia: STEP_F STEP_B
// MO-mosfet, w��cza pr�d na cewce silnika
// BI-bipolarny, steruje kierunkiem pr�du na cewce silnika, przez przeka�niki

#define A_MO_INIT OUT_INIT(D,5)
#define A_MO_ON OUT_ON(D,5)
#define A_MO_OFF OUT_OFF(D,5)

#define A_BI_INIT OUT_INIT(D,6)
#define A_BI_ON OUT_ON(D,6)
#define A_BI_OFF OUT_OFF(D,6)

#define B_MO_INIT OUT_INIT(D,7)
#define B_MO_ON OUT_ON(D,7)
#define B_MO_OFF OUT_OFF(D,7)

#define B_BI_INIT OUT_INIT(B,0)
#define B_BI_ON OUT_ON(B,0)
#define B_BI_OFF OUT_OFF(B,0)

#define STEP_F_INIT IN_INIT(C,2)
#define STEP_F_TEST IN_TEST(C,2)

#define STEP_B_INIT IN_INIT(C,5)
#define STEP_B_TEST IN_TEST(C,5)

#define RELAY_DELAY 10
#define MOSFET_DELAY 40

void pulse_A_PLUS() {
	_delay_ms(RELAY_DELAY);
	A_MO_ON
	_delay_ms(MOSFET_DELAY);
	A_MO_OFF
};
void pulse_A_MINUS() {
	A_BI_ON
	_delay_ms(RELAY_DELAY);
	A_MO_ON
	_delay_ms(MOSFET_DELAY);
	A_MO_OFF
	A_BI_OFF
};
void pulse_B_PLUS(){
	_delay_ms(RELAY_DELAY);
	B_MO_ON
	_delay_ms(MOSFET_DELAY);
	B_MO_OFF
}
void pulse_B_MINUS(){
	B_BI_ON
	_delay_ms(RELAY_DELAY);
	B_MO_ON
	_delay_ms(MOSFET_DELAY);
	B_MO_OFF
	B_BI_OFF
}

void USARTInit(uint16_t ubrr_value)
{
	UBRRL = ubrr_value;
	UBRRH = (ubrr_value>>8);
	UCSRC=(1<<URSEL)|(3<<UCSZ0);
	UCSRB=(1<<RXEN)|(1<<TXEN);
}

void USARTSendString(char s[])
{
	int i =0;
	while (s[i] != 0x00)
	{
		while(!(UCSRA & (1<<UDRE)));
		UDR=s[i];
		i++;
	}
}


char toStringBuffer[20];
char* toString(int value){
	itoa(value,toStringBuffer,10);
	return toStringBuffer;
}

int main(void)
{

	A_MO_INIT
	A_BI_INIT
	B_MO_INIT
	B_BI_INIT
	
	STEP_F_INIT
	STEP_B_INIT
	
	USARTInit(51);
	int step=0;
	
	char phase_fwd=0;
	char phase_bck=0;
	char pressed_fwd=0;
	char pressed_bck=0;
	
	while(1)
	{
		A_MO_OFF
		A_BI_OFF
		B_MO_OFF
		B_BI_OFF
		
		pressed_fwd=0;
		pressed_bck=0;
		
		if (STEP_F_TEST)
		{
			phase_fwd = (phase_fwd+1)%4;
			pressed_fwd =1;
			step++;
		}
		if (STEP_B_TEST)
		{
			phase_bck = (phase_bck+1)%4;
			pressed_bck =1;
			step--;
		}
		
		if (pressed_fwd || pressed_bck){
			USARTSendString("\r      \r");
			USARTSendString(toString(step));
		}
		
		if (pressed_fwd)
		{
			switch (phase_fwd) {
				case 0:	pulse_B_PLUS(); break;
				case 1:	pulse_A_PLUS(); break;
				case 2:	pulse_B_MINUS(); break;
				case 3: pulse_A_MINUS(); break;
			}
			pressed_fwd=0;
			phase_bck=(phase_fwd-1)%4;
		}

		if (pressed_bck)
		{
			switch (phase_bck) {
				case 0:	pulse_A_PLUS(); break;
				case 1:	pulse_B_PLUS(); break;
				case 2:	pulse_A_MINUS(); break;
				case 3: pulse_B_MINUS(); break;
			}
			//pressed_fwd=0;   // tu by� ca�y czas b��d, ale na przeka�nikach nie by�o go wida�
			pressed_bck=0;
			phase_fwd=(phase_bck+1)%4;
		}
		
		_delay_ms(100);
		
	}

}

#endif

