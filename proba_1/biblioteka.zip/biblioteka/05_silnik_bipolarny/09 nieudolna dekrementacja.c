
#include "00 informacje o projekcie.h"

#ifdef ITERACJA_09

// Podpi�cie L298 na porcie D, bo portu C nie da�o si� zwolni�.
// Pr�bowa�em prze�o�y� klawiatur� na D5 D6 D7 B0 ale nie zadzia�a�o.
// 08_test_przycisk�w/ITERACJA 09 pokazuje, �e trzeci rz�d klawiszy nie dzia�a.

#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>

// ---- header ports.h, niezale�ny od urz�dzenia, chyba najlepsza opcja

// inicjowanie pojedynczych bit�w jako wej�cie lub wyj�cie
#define OUT_INIT(port,pin) DDR##port |= 1<<pin; PORT##port &= !(1<<pin);
#define OUT_OFF(port,pin) PORT##port &= !(1<<pin);
#define OUT_ON(port,pin) PORT##port |= (1<<pin);
#define IN_INIT(port,pin) DDR##port &= !(1<<pin); PORT##port |= 1<<pin;
#define IN_TEST(port,pin) (!(PIN##port & (1<<pin)))
// inicjowanie ca�ego portu jako wej�cie lub wyj�cie
#define OUT_INIT_PORT(port) DDR##port = 0xFF; PORT##port = 0x00;
#define IN_INIT_PORT(port) DDR##port = 0x00; PORT##port = 0xFF;

// koniec ports.h

// ---- definicja interfejsu

// wejscia
// porty:        D5   D6
// znaczenie:    FWD  BCK
// wyj�cia
// porty:        C3   C2   C1   C0
// znaczenie:    in4  in3  in2  in1

// koniec definicji interfejsu

// definicja sekwencji steruj�cej dla L298
// wej�cia enable w��czone na sta�e

// kolejno�� B- B+ A- A+
unsigned char seq_fwd[4]={
	0b00000100,  // f0 B+ = b1 nb2
	0b00000001,  // f1 A+ = b0 nb1
	0b00001000,  // f2 B- = b3 nb0
	0b00000010   // f3 A- = b2 nb3
	//  0b01100000,	 // f4 B+ = b1
};
unsigned char seq_bck[4]={
	0b00000001,  // b0 A+ = f1 nf2
	0b00000100,  // b1 B+ = f0 nf1
	0b00000010,  // b2 A- = f3 nf0
	0b00001000   // b3 B- = f2 nf3
	//	0b00000110,  // b0 A+ = f1
};

unsigned char next_in_reverse(unsigned char i) {
	switch (i) {
		case 0: return 2;
		case 1: return 1;
		case 2: return 0;
		case 3: return 3;
		default: return 0;
	}
}

void delay_ms(uint16_t count) {
	while(count--) {
		_delay_ms(1);

	}
}

#define PULSE_DELAY 10
#define STEP_DELAY 1

int main(void)
{

	OUT_INIT_PORT(D)
	IN_INIT(C,5)
	#define FWD_TEST IN_TEST(C,5)
	IN_INIT(C,2)
	#define BCK_TEST IN_TEST(C,2)
	
	int pulse_delay=PULSE_DELAY;
	
	unsigned char phase_fwd=0;
	unsigned char phase_bck=0;
	
	while(1)
	{
		
		if (FWD_TEST)
		{
			PORTD=seq_fwd[phase_fwd];
			delay_ms(pulse_delay);
			PORTD=0x00;

			phase_bck = next_in_reverse(phase_fwd);
			phase_fwd = (phase_fwd+1)%4;
			
		}

		if (BCK_TEST)
		{
			PORTD=seq_bck[phase_bck];
			delay_ms(pulse_delay);
			PORTD=0x00;
			
			phase_fwd = next_in_reverse(phase_bck);
			phase_bck = (phase_bck+1)%4;
		}
		
		_delay_ms(STEP_DELAY);
		
	}
	
}

#endif

