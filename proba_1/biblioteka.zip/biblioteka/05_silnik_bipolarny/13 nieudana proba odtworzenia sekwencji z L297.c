
#include "00 informacje o projekcie.h"

#ifdef ITERACJA_13

// po��czenie dzia�ania iteracji 11 i 12
// co� nie dzia�a elektrycznie, do��czy�em drugi mostek

#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>

// ---- header ports.h, niezale�ny od urz�dzenia, chyba najlepsza opcja

// inicjowanie pojedynczych bit�w jako wej�cie lub wyj�cie
#define OUT_INIT(port,pin) DDR##port |= 1<<pin; PORT##port &= !(1<<pin);
#define OUT_OFF(port,pin) PORT##port &= !(1<<pin);
#define OUT_ON(port,pin) PORT##port |= (1<<pin);
#define IN_INIT(port,pin) DDR##port &= !(1<<pin); PORT##port |= 1<<pin;
#define IN_TEST(port,pin) (!(PIN##port & (1<<pin)))
// inicjowanie ca�ego portu jako wej�cie lub wyj�cie
#define OUT_INIT_PORT(port) DDR##port = 0xFF; PORT##port = 0x00;
#define IN_INIT_PORT(port) DDR##port = 0x00; PORT##port = 0xFF;

// koniec ports.h

// ---- definicja interfejsu

// wejscia
// porty:        C5   C2   C1
// znaczenie:    FWD  BCK  TOGGLE
// wyj�cia
// porty:        C4   C3   C2   C1   C0
// znaczenie:    CLK  D    C    B    A

// s� dwa tryby dzia�ania - wysy�anie sekwencji i taktowanie sterownika
// prze��czanie trzecim przyciskiem, sygnalizowane diod�

// koniec definicji interfejsu

// definicja sekwencji steruj�cej dla L298
// wej�cia enable w��czone na sta�e
// wej�cia inh w��czone do L297 ale to nie przeszkadza

// kolejno��  D C B A
unsigned char state[4]={
	0b00001010,
	0b00001001,
	0b00000101,
	0b00000110
};

// T=50ms f=20Hz
// T=30ms f=33Hz
// T=20ms f=50Hz
// T=1ms  f=1000Hz=1kHz

// MS25SP-5T
// 730~1700pps = 730Hz~1700Hz ?
// 0,00136~0,000588s

#define STEP_DURATION 50
#define DEBOUNCE_DURATION 10

int main(void)
{

	OUT_INIT_PORT(D)
	IN_INIT(C,5)
	#define FWD_TEST IN_TEST(C,5)
	IN_INIT(C,2)
	#define BCK_TEST IN_TEST(C,2)
	IN_INIT(C,1)
	#define TOGGLE_TEST IN_TEST(C,1)
	
	unsigned char phase=0;
	unsigned char mode=0;
	PORTD=state[phase];

	while(1)
	{
		
		if (TOGGLE_TEST) {
			mode = ! mode;
			_delay_ms(CLOCK_DURATION);
		}
		
		if (mode==0) {
			
			OUT_OFF(D,7)
			
			if (FWD_TEST)
			{
				phase = (phase+1)%4;
				PORTD=state[phase];
				_delay_ms(STEP_DURATION);
			}

			if (BCK_TEST)
			{
				//phase = (phase-1)%4;   // nieprawid�owa dekrementacja modulo
				phase = (phase+3)%4;
				PORTD=state[phase];
				_delay_ms(STEP_DURATION);
			}
		}
		else
		{
			OUT_ON(D,7)
			
			// wys�anie impulsu zerowego
			if (FWD_TEST)
			{
				_delay_ms(CLOCK_DURATION);
				PORTD &= 0x11101111;
				_delay_ms(10);
				PORTD |= 0x00010000;
			}
			
		}
		
		_delay_ms(DEBOUNCE_DURATION);
		
	}
	
}

#endif

