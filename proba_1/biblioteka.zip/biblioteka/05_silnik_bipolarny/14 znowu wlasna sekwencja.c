
#include "00 informacje o projekcie.h"

#ifdef ITERACJA_14

// po��czenie dzia�ania iteracji 11 i 12, bez prze��czania
// jednoczesne sterowanie generatorem sekwencji i mostkiem

#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>

// ---- header ports.h, niezale�ny od urz�dzenia, chyba najlepsza opcja

// inicjowanie pojedynczych bit�w jako wej�cie lub wyj�cie
#define OUT_INIT(port,pin) DDR##port |= 1<<pin; PORT##port &= !(1<<pin);
#define OUT_OFF(port,pin) PORT##port &= !(1<<pin);
#define OUT_ON(port,pin) PORT##port |= (1<<pin);
#define IN_INIT(port,pin) DDR##port &= !(1<<pin); PORT##port |= 1<<pin;
#define IN_TEST(port,pin) (!(PIN##port & (1<<pin)))
// inicjowanie ca�ego portu jako wej�cie lub wyj�cie
#define OUT_INIT_PORT(port) DDR##port = 0xFF; PORT##port = 0x00;
#define IN_INIT_PORT(port) DDR##port = 0x00; PORT##port = 0xFF;

// koniec ports.h

// ---- definicja interfejsu

// wejscia
// porty:        C5   C2
// znaczenie:    FWD  BCK
// wyj�cia
// porty:        C3   C2   C1   C0     B1
// znaczenie:    D    C    B    A      CLK

// s� dwa tryby dzia�ania - wysy�anie sekwencji i taktowanie sterownika
// prze��czanie trzecim przyciskiem, sygnalizowane diod�

// koniec definicji interfejsu

// definicja sekwencji steruj�cej dla L298
// wej�cia enable w��czone na sta�e
// wej�cia inh w��czone do L297 ale to nie przeszkadza

// kolejno��  D C B A
unsigned char state[4]={
	0b00001010,
	0b00001001,
	0b00000101,
	0b00000110
};

// T=50ms f=20Hz
// T=30ms f=33Hz
// T=20ms f=50Hz
// T=1ms  f=1000Hz=1kHz

// MS25SP-5T
// 730~1700pps = 730Hz~1700Hz ?
// 0,00136~0,000588s

#define STEP_DURATION 50
#define DEBOUNCE_DURATION 10

void clk_pulse() {
	PORTB=0x00;
	_delay_ms(10);
	PORTB=0xFF;
}

int main(void)
{

	OUT_INIT_PORT(D)
	OUT_INIT_PORT(B)
	IN_INIT(C,5)
	#define FWD_TEST IN_TEST(C,5)
	IN_INIT(C,2)
	#define BCK_TEST IN_TEST(C,2)
	
	unsigned char phase=0;
	//unsigned char mode=0;
	PORTD=state[phase];
	
	PORTB=0xFF;

	while(1)
	{
		
		if (FWD_TEST)
		{
			phase = (phase+1)%4;
			PORTD=state[phase];
			_delay_ms(STEP_DURATION);
			clk_pulse();
		}

		if (BCK_TEST)
		{
			phase = (phase+3)%4;
			PORTD=state[phase];
			_delay_ms(STEP_DURATION);
			clk_pulse();
		}
		
		_delay_ms(DEBOUNCE_DURATION);
		
	}
	
}

#endif
