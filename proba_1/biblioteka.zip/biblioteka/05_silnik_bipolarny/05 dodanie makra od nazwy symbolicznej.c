
#include "00 informacje o projekcie.h"

#ifdef ITERACJA_05

// wprawka do podawania sekwencji jako tablicy
// potrzebne proste indeksowanie bit�w w portach
// napisane po zrobieniu ITERACJA 9 w 03_test_przyciskow.cpp
// i jeszcze poprawiona forma ports_m8a.h, zadzia�a�o od razu
// Dyskusja przydatno�ci.
// rozmiar ca�kowity
//				Program Memory Usage 	:	1212 bytes   14,8 % Full
//				Data Memory Usage 		:	30 bytes   2,9 % Full
// // init_ports();
//				Program Memory Usage 	:	964 bytes   11,8 % Full
//				Data Memory Usage 		:	30 bytes   2,9 % Full
// volatile uint8_t dummy; #define PORT(port) dummy
//				Program Memory Usage 	:	918 bytes   11,2 % Full
//				Data Memory Usage 		:	31 bytes   3,0 % Full
// Wi�c to dwustopniowe indeksowanie bit�w w portach daje taki narzut, 10%
// Fajnie wygl�da, ale nieprzydatne.


#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>
#include <stdint.h>    // uint8_t

// ---- header ports_m8a.h

// cz�� specyficzna dla atmega8
// makra s� z plik�w
// C:\Program Files\Atmel\Atmel Toolchain\AVR8 GCC\Native\3.4.1061\avr8-gnu-toolchain\avr\include\avr
// iom8a.h sfr_defs.h

#define D 0x12
#define C 0x15
#define B 0x18

#define PORT(port) _SFR_IO8(port)
#define DDR(port) _SFR_IO8(port-1)
#define PIN(port) _SFR_IO8(port-2)

// u�yte przy sprawdzaniu co daje narzut
//volatile uint8_t dummy;
//#define PORT(port) dummy
//#define DDR(port) dummy
//#define PIN(port) dummy

// cz�� dla wszystkich kontroler�w

#define OUTPUT_INIT(port,pin) {DDR(port) |= 1<<pin; PORT(port) &= !(1<<pin);}
#define INPUT_INIT(port,pin) {DDR(port) &= !(1<<pin); PORT(port) |= 1<<pin;}

#define SET_ADR(port,pin,bit) {if(bit) PORT(port) |= (1<<pin); else PORT(port) &= !(1<<pin);}
#define TEST_ADR(port,pin) (!(PIN(port) & (1<<pin)))
#define ON_ADR(port,pin) {PORT(port) |= (1<<pin);}
#define OFF_ADR(port,pin) {PORT(port) &= !(1<<pin);}

#define ON(no) ON_ADR(lookup[no*3],lookup[no*3+1])
#define OFF(no) OFF_ADR(lookup[no*3],lookup[no*3+1])
#define SET(no,bit) SET_ADR(lookup[no*3],lookup[no*3+1],bit)
#define TEST(no) TEST_ADR(lookup[no*3],lookup[no*3+1])

// poni�sza funkcja u�ywa tablicy lookup i sta�ej PORTS_NO
// kt�re s� specyficzne dla aktualnego interfejsu port�w
// wi�c nie mo�e by� w pliku nag��wkowym
// trzeba to makro wywo�a� w kodzie g��wnym po deklaracji lookup i PORTS_NO

// tablica lookup ma zawiera� tr�jki liczb dla ka�dego bitu:
// adres_portu, numer_bitu, typ_0input_1output
// PORTS_NO to ilo�� tych definiowanych bit�w

// przyk�adowa definicja interfejsu:
// #define PORTS_NO 2
// uint8_t lookup[PORTS_NO*3] = {D,5,1,C,5,0};  // port,pin,type
// #define LED1 0
// #define SWITCH1 3
// DEFINE_INIT_PORTS_FUNCTION

#define DEFINE_INIT_PORTS_FUNCTION \
void init_ports() { \
	for (uint8_t  i=0; i<=PORTS_NO*3; i+=3) \
	if (lookup[i+2]) \
	OUTPUT_INIT(lookup[i],lookup[i+1]) \
	else \
	INPUT_INIT(lookup[i],lookup[i+1]) \
}

// koniec ports_m8a.h

// ---- definicja interfejsu

// wejscia
// porty:        C5   C2
// znaczenie:    FWD  BCK
// wyj�cia
// porty:        D1   D2   D3   D4   B1   B2   B3   B4
// znaczenie:    APD  APU  AMD  AMU  BPD  BPU  BMD  BMU

#define PORTS_NO 10
uint8_t lookup[PORTS_NO*3]={
	D,1,1, D,2,1, D,3,1, D,4,1,
	B,1,1, B,2,1, B,3,1, B,4,1,
	C,2,0, C,5,0
};
#define APD 0
#define APU 1
#define AMD 2
#define AMU 3
#define BPD 4
#define BPU 5
#define BMD 6
#define BMU 7
#define FWD 8
#define BCK 9

DEFINE_INIT_PORTS_FUNCTION

// koniec definicji interfejsu

// ---- definicja sterowania mostkiem

#define PULSE_DELAY 40
#define STEP_DELAY 100

void pulse_A_PLUS() {
	ON(APU)
	ON(AMD)
	_delay_ms(PULSE_DELAY);
	OFF(APU)
	OFF(AMD)
};
void pulse_A_MINUS() {
	ON(APD)
	ON(AMU)
	_delay_ms(PULSE_DELAY);
	OFF(APD)
	OFF(AMU)
};
void pulse_B_PLUS() {
	ON(BPU)
	ON(BMD)
	_delay_ms(PULSE_DELAY);
	OFF(BPU)
	OFF(BMD)
};
void pulse_B_MINUS() {
	ON(BPD)
	ON(BMU)
	_delay_ms(PULSE_DELAY);
	OFF(BPD)
	OFF(BMU)
};

// koniec definicji sterowania mostkiem

int main(void)
{

	// ---- definicja sterowania krokami

	init_ports();
	
	int step=0;
	
	char phase_fwd=0;
	char phase_bck=0;
	char pressed_fwd=0;
	char pressed_bck=0;
	
	while(1)
	{
		
		pressed_fwd=0;
		pressed_bck=0;
		
		if (TEST(FWD))
		{
			phase_fwd = (phase_fwd+1)%4;
			pressed_fwd =1;
			step++;
		}
		if (TEST(BCK))
		{
			phase_bck = (phase_bck+1)%4;
			pressed_bck =1;
			step--;
		}
		
		if (pressed_fwd)
		{
			switch (phase_fwd) {
				case 0:	pulse_B_PLUS(); break;
				case 1:	pulse_A_PLUS(); break;
				case 2:	pulse_B_MINUS(); break;
				case 3: pulse_A_MINUS(); break;
			}
			pressed_fwd=0;
			phase_bck=(phase_fwd)%4;
		}

		if (pressed_bck)
		{
			switch (phase_bck) {
				case 0:	pulse_A_PLUS(); break;
				case 1:	pulse_B_PLUS(); break;
				case 2:	pulse_A_MINUS(); break;
				case 3: pulse_B_MINUS(); break;
			}
			pressed_bck=0;
			phase_fwd=(phase_bck)%4;
		}
		
		_delay_ms(STEP_DELAY);
		
	}

}

#endif
