
#include "00 informacje o projekcie.h"

#ifdef ITERACJA_16

// generowanie sekwencji jak w 11, ale na C0,C1,C2,C5 (IDC 6,4,2,1)
// sterowanie kierunkiem pinami D5,D6 (IDC 1,2)

#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>

// ---- header ports.h, niezale�ny od urz�dzenia, chyba najlepsza opcja

// inicjowanie pojedynczych bit�w jako wej�cie lub wyj�cie
#define OUT_INIT(port,pin) DDR##port |= 1<<pin; PORT##port &= !(1<<pin);
#define OUT_OFF(port,pin) PORT##port &= !(1<<pin);
#define OUT_ON(port,pin) PORT##port |= (1<<pin);
#define IN_INIT(port,pin) DDR##port &= !(1<<pin); PORT##port |= 1<<pin;
#define IN_TEST(port,pin) (!(PIN##port & (1<<pin)))
// inicjowanie ca�ego portu jako wej�cie lub wyj�cie
#define OUT_INIT_PORT(port) DDR##port = 0xFF; PORT##port = 0x00;
#define IN_INIT_PORT(port) DDR##port = 0x00; PORT##port = 0xFF;

// koniec ports.h

// ---- definicja interfejsu

// generowanie sekwencji jak w 11, ale na C0,C1,C2,C5 (IDC 6,4,2,1 dla gniazda 1,1 p�ytki M)
// sterowanie kierunkiem pinami D5,D6 (IDC 1,2 dla gniazda 1,3 p�ytki M)

// wejscia
// porty:        D5   D6
// znaczenie:    CW   CCW   (patrz�c od strony osi)
// wyj�cia
// porty:        C5   C2   C1   C0
// znaczenie:    D    C    B    A

// koniec definicji interfejsu

// jest tak�e generator przebiegu steruj�cego dla L298
// wej�cia enable w��czone na sta�e
// wej�cia inh w��czone do L297 ale to nie przeszkadza

// kolejno��  D C B A
unsigned char states[4]={
	0b0100010,
	0b0100001,
	0b0000101,
	0b0000110
};

// 30ms = 33Hz
// 20ms = 50Hz
// 1ms  = 1000Hz = 1kHz

// MS25SP-5T
// 730~1700pps = 730Hz~1700Hz ?
// 0,00136 ~ 0,000588 s

#define STEP_DURATION 100
#define DEBOUNCE_DURATION 10

int main(void)
{

	IN_INIT_PORT(D)
	OUT_INIT_PORT(C)
	
	IN_INIT(D,5)
	#define FWD_TEST IN_TEST(D,5)
	IN_INIT(D,6)
	#define BCK_TEST IN_TEST(D,6)
	
	unsigned char phase=0;
	PORTC=states[phase];

	while(1)
	{
		
		if (FWD_TEST)
		{
			phase = (phase+1)%4;
			PORTC=states[phase];
			_delay_ms(STEP_DURATION);
		}

		if (BCK_TEST)
		{
			phase = (phase+3)%4;
			PORTC=states[phase];
			_delay_ms(STEP_DURATION);
		}
		
		_delay_ms(DEBOUNCE_DURATION);
		
	}
	
}

#endif
