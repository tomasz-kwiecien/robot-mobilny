
#include "00 informacje o projekcie.h"

#ifdef ITERACJA_06

// Takie indeksowane generowanie sekwencji nie ma sensu.
// Powinna by� funkcja kt�ra zapisuje od razu osiem bit�w do rejestru D
// i nawet niczego nie zeruje mi�dzy kolejnymi krokami.
// Jak jest pod��czony kwarc to tylko rejetr D jest ca�y wolny w atmega8
// Ale przydatna tylko do zbadania sterowania, bo do tego s� specjalizowane uk�ady.
// L298 mostki �eby sterowa� 4 liniami a nie 8 - 9,40 z�
// L297 genrator sekwencji �eby w og�le nic nie oblicza� - 11 z�
// TMC211 mikrokroki, podzia� kroku, pwm, gaszenie, mniej lutowania - 33 z�

#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>

// ---- header ports.h, niezale�ny od urz�dzenia, chyba najlepsza opcja

// inicjowanie pojedynczych bit�w jako wej�cie lub wyj�cie
#define OUT_INIT(port,pin) DDR##port |= 1<<pin; PORT##port &= !(1<<pin);
#define OUT_OFF(port,pin) PORT##port &= !(1<<pin);
#define OUT_ON(port,pin) PORT##port |= (1<<pin);
#define IN_INIT(port,pin) DDR##port &= !(1<<pin); PORT##port |= 1<<pin;
#define IN_TEST(port,pin) (!(PIN##port & (1<<pin)))
// inicjowanie ca�ego portu jako wej�cie lub wyj�cie
#define OUT_INIT_PORT(port) DDR##port = 0xFF; PORT##port = 0x00;
#define IN_INIT_PORT(port) DDR##port = 0x00; PORT##port = 0xFF;

// koniec ports.h

// ---- definicja interfejsu

// wejscia
// porty:        C5   C2
// znaczenie:    FWD  BCK
// wyj�cia
// porty:        D0   D1   D2   D3   D4   D5   D6   D7
// znaczenie:    APD  APU  AMD  AMU  BPD  BPU  BMD  BMU
//
// D7   D6   D5   D4   D3   D2   D1   D0
// BMU  BMD  BPU  BPD  AMU  AMD  APU  APD

#define FWD_INIT IN_INIT(C,5)
#define FWD_TEST IN_TEST(C,5)

#define BCK_INIT IN_INIT(C,2)
#define BCK_TEST IN_TEST(C,2)

// koniec definicji interfejsu

// ---- definicja sterowania mostkiem

#define PULSE_DELAY 40
#define STEP_DELAY 100

void pulse_A_PLUS() {
	PORTD=0b00000110;
	//	ON(APU)
	//	ON(AMD)
	_delay_ms(PULSE_DELAY);
	PORTD=0b00000000;
	//	OFF(APU)
	//	OFF(AMD)
};
void pulse_A_MINUS() {
	PORTD=0b00001001;
	//	ON(APD)
	//	ON(AMU)
	_delay_ms(PULSE_DELAY);
	PORTD=0b00000000;
	//	OFF(APD)
	//	OFF(AMU)
};
void pulse_B_PLUS() {
	PORTD=0b01100000;
	//	ON(BPU)
	//	ON(BMD)
	_delay_ms(PULSE_DELAY);
	PORTD=0b00000000;
	//	OFF(BPU)
	//	OFF(BMD)
};
void pulse_B_MINUS() {
	PORTD=0b10010000;
	//	ON(BPD)
	//	ON(BMU)
	_delay_ms(PULSE_DELAY);
	PORTD=0b00000000;
	//	OFF(BPD)
	//	OFF(BMU)
};

int main(void)
{

	OUT_INIT_PORT(D)
	FWD_INIT
	BCK_INIT
	
	int step=0;
	
	char phase_fwd=0;
	char phase_bck=0;
	char pressed_fwd=0;
	char pressed_bck=0;
	
	while(1)
	{
		
		pressed_fwd=0;
		pressed_bck=0;
		
		if (FWD_TEST)
		{
			phase_fwd = (phase_fwd+1)%4;
			pressed_fwd =1;
			step++;
		}
		if (BCK_TEST)
		{
			phase_bck = (phase_bck+1)%4;
			pressed_bck =1;
			step--;
		}
		
		if (pressed_fwd)
		{
			switch (phase_fwd) {
				case 0:	pulse_B_PLUS(); break;
				case 1:	pulse_A_PLUS(); break;
				case 2:	pulse_B_MINUS(); break;
				case 3: pulse_A_MINUS(); break;
			}
			pressed_fwd=0;
			phase_bck=(phase_fwd)%4;
		}

		if (pressed_bck)
		{
			switch (phase_bck) {
				case 0:	pulse_A_PLUS(); break;
				case 1:	pulse_B_PLUS(); break;
				case 2:	pulse_A_MINUS(); break;
				case 3: pulse_B_MINUS(); break;
			}
			pressed_bck=0;
			phase_fwd=(phase_bck)%4;
		}
		
		_delay_ms(STEP_DELAY);
		
	}
	
}

#endif

