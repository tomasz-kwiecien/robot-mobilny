
#include "00 informacje o projekcie.h"

#ifdef ITERACJA_11

// Sekwencja dwufazowa.
// Dzia�a bipolarny i unipolarny, tak�e przez L298.
// B��d by� w obliczaniu dekrementacji.

#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>

// ---- header ports.h, niezale�ny od urz�dzenia, chyba najlepsza opcja

// inicjowanie pojedynczych bit�w jako wej�cie lub wyj�cie
#define OUT_INIT(port,pin) DDR##port |= 1<<pin; PORT##port &= !(1<<pin);
#define OUT_OFF(port,pin) PORT##port &= !(1<<pin);
#define OUT_ON(port,pin) PORT##port |= (1<<pin);
#define IN_INIT(port,pin) DDR##port &= !(1<<pin); PORT##port |= 1<<pin;
#define IN_TEST(port,pin) (!(PIN##port & (1<<pin)))
// inicjowanie ca�ego portu jako wej�cie lub wyj�cie
#define OUT_INIT_PORT(port) DDR##port = 0xFF; PORT##port = 0x00;
#define IN_INIT_PORT(port) DDR##port = 0x00; PORT##port = 0xFF;

// koniec ports.h

// ---- definicja interfejsu

// wejscia
// porty:        D5   D6
// znaczenie:    FWD  BCK
// wyj�cia
// porty:        C3   C2   C1   C0
// znaczenie:    D    C    B    A

// koniec definicji interfejsu

// definicja sekwencji steruj�cej dla L298
// wej�cia enable w��czone na sta�e
// wej�cia inh w��czone do L297 ale to nie przeszkadza

// kolejno��  D C B A
unsigned char state[4]={
	0b00001010,
	0b00001001,
	0b00000101,
	0b00000110
};

// 30ms = 33Hz
// 20ms = 50Hz
// 1ms  = 1000Hz = 1kHz

// MS25SP-5T
// 730~1700pps = 730Hz~1700Hz ?
// 0,00136 ~ 0,000588 s

#define STEP_DURATION 20
#define DEBOUNCE_DURATION 10

int main(void)
{

	OUT_INIT_PORT(D)
	IN_INIT(C,5)
	#define FWD_TEST IN_TEST(C,5)
	IN_INIT(C,2)
	#define BCK_TEST IN_TEST(C,2)
	
	unsigned char phase=0;
	PORTD=state[phase];

	while(1)
	{
		
		if (FWD_TEST)
		{
			phase = (phase+1)%4;
			PORTD=state[phase];
			_delay_ms(STEP_DURATION);
		}

		if (BCK_TEST)
		{
			//phase = (phase-1)%4;   // nieprawid�owa dekrementacja modulo
			phase = (phase+3)%4;
			PORTD=state[phase];
			_delay_ms(STEP_DURATION);
		}
		
		_delay_ms(DEBOUNCE_DURATION);
		
	}
	
}

#endif

