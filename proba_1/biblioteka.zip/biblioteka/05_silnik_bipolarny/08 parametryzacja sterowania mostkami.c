
#include "00 informacje o projekcie.h"

#ifdef ITERACJA_06

// Zapis sekwencji steruj�cej w formie sygna��w A+ A- B+ B
// Gdy nie ma przerwy mi�dzy impulsami to zacina si� nawet przy pulsie 15ms.


#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>

// ---- header ports.h, niezale�ny od urz�dzenia, chyba najlepsza opcja

// inicjowanie pojedynczych bit�w jako wej�cie lub wyj�cie
#define OUT_INIT(port,pin) DDR##port |= 1<<pin; PORT##port &= !(1<<pin);
#define OUT_OFF(port,pin) PORT##port &= !(1<<pin);
#define OUT_ON(port,pin) PORT##port |= (1<<pin);
#define IN_INIT(port,pin) DDR##port &= !(1<<pin); PORT##port |= 1<<pin;
#define IN_TEST(port,pin) (!(PIN##port & (1<<pin)))
// inicjowanie ca�ego portu jako wej�cie lub wyj�cie
#define OUT_INIT_PORT(port) DDR##port = 0xFF; PORT##port = 0x00;
#define IN_INIT_PORT(port) DDR##port = 0x00; PORT##port = 0xFF;

// koniec ports.h

// ---- definicja interfejsu

// wejscia
// porty:        C5   C2    C1   C0
// znaczenie:    FWD  BCK   PP   PM
// wyj�cia
// porty:        D0   D1   D2   D3   D4   D5   D6   D7
// znaczenie:    APD  APU  AMD  AMU  BPD  BPU  BMD  BMU
//
// D7   D6   D5   D4   D3   D2   D1   D0
// BMU  BMD  BPU  BPD  AMU  AMD  APU  APD

// koniec definicji interfejsu

// ---- definicja sterowania mostkiem i silnikiem

#define AP 0b00000110
#define AM 0b00001001
#define BP 0b01100000
#define BM 0b10010000

// tymczasowa wersja nieoptymalna
#define H_BRIDGES(b) (BM*((b>>3)&0x01) | BP*((b>>2)&0x01) | AM*((b>>1)&0x01) | AP*(b&0x01))

// kolejno�� B- B+ A- A+
unsigned char seq_fwd[4]={
	0b00000100,  // f0 B+ = b1 nb2
	0b00000001,  // f1 A+ = b0 nb1
	0b00001000,  // f2 B- = b3 nb0
	0b00000010   // f3 A- = b2 nb3
	//  0b01100000,	 // f4 B+ = b1
};
unsigned char seq_bck[4]={
	0b00000001,  // b0 A+ = f1 nf2
	0b00000100,  // b1 B+ = f0 nf1
	0b00000010,  // b2 A- = f3 nf0
	0b00001000   // b3 B- = f2 nf3
	//	0b00000110,  // b0 A+ = f1
};

unsigned char next_in_reverse(unsigned char i) {
	switch (i) {
		case 0: return 2;
		case 1: return 1;
		case 2: return 0;
		case 3: return 3;
		default: return 0;
	}
}

void delay_ms(uint16_t count) {
	while(count--) {
		_delay_ms(1);

	}
}

#define PULSE_DELAY 10
#define STEP_DELAY 1

int main(void)
{

	OUT_INIT_PORT(D)
	IN_INIT(C,5)
	#define FWD_TEST IN_TEST(C,5)
	IN_INIT(C,2)
	#define BCK_TEST IN_TEST(C,2)
	IN_INIT(C,1)
	#define PP_TEST IN_TEST(C,2)
	IN_INIT(C,0)
	#define PM_TEST IN_TEST(C,0)
	
	int pulse_delay=PULSE_DELAY;
	
	unsigned char phase_fwd=0;
	unsigned char phase_bck=0;
	
	while(1)
	{
		//
		//if (PP_TEST)
		//pulse_delay=(pulse_delay+1)%PULSE_DELAY;
		//if (PM_TEST)
		//pulse_delay=(pulse_delay-1)%PULSE_DELAY;
		//---- te klawisze nie dzia�aj�
		
		if (FWD_TEST )
		{
			PORTD=H_BRIDGES(seq_fwd[phase_fwd]);
			delay_ms(pulse_delay);
			PORTD=0x00;

			phase_bck = next_in_reverse(phase_fwd);
			phase_fwd = (phase_fwd+1)%4;
			
		}

		if (BCK_TEST )
		{
			PORTD=H_BRIDGES(seq_bck[phase_bck]);
			delay_ms(pulse_delay);
			PORTD=0x00;
			
			phase_fwd = next_in_reverse(phase_bck);
			phase_bck = (phase_bck+1)%4;
		}
		
		_delay_ms(STEP_DELAY);
		
	}
	
}

#endif

