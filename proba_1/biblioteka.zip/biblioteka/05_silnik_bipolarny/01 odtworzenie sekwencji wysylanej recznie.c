
#include "00 informacje o projekcie.h"

#ifdef ITERACJA_01

// sterowanie krokowe poprzez przeka�niki
// proste dublowania dzia�ania przycisk�w dla przetestowania p�ytki
// zmieni�em mosfety na takie kt�re wymaga�y mniejszego napi�cia na bramce
//				Program Memory Usage 	:	154 bytes   1,9 % Full
//				Data Memory Usage 		:	0 bytes   0,0 % Full

#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>

// header port_macros.h

#define OUT_INIT(port,pin) DDR##port |= 1<<pin; PORT##port &= !(1<<pin);
#define OUT_OFF(port,pin) PORT##port &= !(1<<pin);
//brakowa�o �rednika po _delay_ms
//#define OUT_OFF(port,pin) ;
#define OUT_ON(port,pin) PORT##port |= (1<<pin);

#define IN_INIT(port,pin) DDR##port &= !(1<<pin); PORT##port |= 1<<pin;
#define IN_TEST(port,pin) (!(PIN##port & (1<<pin)))

// interfejs p�ytki, wej�cia: C5 C2 C1 C0, wyj�cia: D5 D6 D7 B0

// konfiguracja, wyj�cia: AP AM BP BM, wej�cia: STEP_F STEP_B

#define A_MO_INIT OUT_INIT(D,5)
#define A_MO_ON OUT_ON(D,5)
#define A_MO_OFF OUT_OFF(D,5)

#define A_BI_INIT OUT_INIT(D,6)
#define A_BI_ON OUT_ON(D,6)
#define A_BI_OFF OUT_OFF(D,6)

#define B_MO_INIT OUT_INIT(D,7)
#define B_MO_ON OUT_ON(D,7)
#define B_MO_OFF OUT_OFF(D,7)

#define B_BI_INIT OUT_INIT(B,0)
#define B_BI_ON OUT_ON(B,0)
#define B_BI_OFF OUT_OFF(B,0)

#define T_A_MO_INIT IN_INIT(C,5)
#define T_A_MO_TEST IN_TEST(C,5)

#define T_A_BI_INIT IN_INIT(C,2)
#define T_A_BI_TEST IN_TEST(C,2)

#define T_B_MO_INIT IN_INIT(C,0)
#define T_B_MO_TEST IN_TEST(C,0)

#define T_B_BI_INIT IN_INIT(C,1)
#define T_B_BI_TEST IN_TEST(C,1)

int main(void)
{

	A_MO_INIT
	A_BI_INIT
	B_MO_INIT
	B_BI_INIT
	
	T_A_MO_INIT
	T_A_BI_INIT
	T_B_MO_INIT
	T_B_BI_INIT
	
	while(1)
	{
		A_MO_OFF
		A_BI_OFF
		B_MO_OFF
		B_BI_OFF
		
		if (T_A_MO_TEST)
		A_MO_ON
		if (T_A_BI_TEST)
		A_BI_ON
		if (T_B_MO_TEST)
		B_MO_ON
		if (T_B_BI_TEST)
		B_BI_ON
		
		_delay_ms(10);
	}

}

#endif

