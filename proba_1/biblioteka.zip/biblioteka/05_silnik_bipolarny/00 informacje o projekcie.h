
// Cel: Poznanie sterowania silnikiem krokowym hybrydowym bipolarnym
// Od biedy identycznie mo�na sterowa� unipolarnym.

//#define ITERACJA_01
//#define ITERACJA_02
//#define ITERACJA_03
//#define ITERACJA_04
//#define ITERACJA_05
//#define ITERACJA_06
//#define ITERACJA_07
//#define ITERACJA_08
//#define ITERACJA_09
//#define ITERACJA_10
//#define ITERACJA_11
//#define ITERACJA_12
//#define ITERACJA_13
//#define ITERACJA_14
//#define ITERACJA_15
#define ITERACJA_16
//#define ITERACJA_17
