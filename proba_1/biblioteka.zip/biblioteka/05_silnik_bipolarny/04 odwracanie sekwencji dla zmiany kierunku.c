
#include "00 informacje o projekcie.h"

#ifdef ITERACJA_04

// zmiana sekwencji wstecznej, to nie dzia�a,
// wi�c odwr�cenie kolejno�ci jest tylko dla unipolarnych
// W ITERACJA 2 wpisa�em sekwencje tak jak zaobserwowa�em podczas u�ywania ITERACJA 1
// potem mia�em w�tpliwo�� czy dobrze to robi� i chcia�em sprawdzi�.
// O odwracaniu kierunku dla bipolarnych nie by�o nic w edw ani w projektach edw.
// Do takiego testu nie ma znaczenia synchronizacja fazy przy zmianie kierunku
// nawet je�li jest b��dna to przy prawid�owej sekwencji silnik zaskoczy
//				Program Memory Usage 	:	350 bytes   4,3 % Full
//				Data Memory Usage 		:	0 bytes   0,0 % Full


#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>

// header port_macros.h

#define OUT_INIT(port,pin) DDR##port |= 1<<pin; PORT##port &= !(1<<pin);
#define OUT_OFF(port,pin) PORT##port &= !(1<<pin);
#define OUT_ON(port,pin) PORT##port |= (1<<pin);

#define IN_INIT(port,pin) DDR##port &= !(1<<pin); PORT##port |= 1<<pin;
#define IN_TEST(port,pin) (!(PIN##port & (1<<pin)))

// interfejs p�ytki
// wejscia
// porty:        C5        C2
// znaczenie:    step_fwd  step_bck
// wyj�cia
// porty:        D1   D2   D3   D4   B1   B2   B3   B4
// znaczenie:    APD  APU  AMD  AMU  BPD  BPU  BMD  BMU

#define APD_INIT OUT_INIT(D,1)
#define APD_ON OUT_ON(D,1)
#define APD_OFF OUT_OFF(D,1)

#define APU_INIT OUT_INIT(D,2)
#define APU_ON OUT_ON(D,2)
#define APU_OFF OUT_OFF(D,2)

#define AMD_INIT OUT_INIT(D,3)
#define AMD_ON OUT_ON(D,3)
#define AMD_OFF OUT_OFF(D,3)

#define AMU_INIT OUT_INIT(D,4)
#define AMU_ON OUT_ON(D,4)
#define AMU_OFF OUT_OFF(D,4)

#define BPD_INIT OUT_INIT(B,1)
#define BPD_ON OUT_ON(B,1)
#define BPD_OFF OUT_OFF(B,1)

#define BPU_INIT OUT_INIT(B,2)
#define BPU_ON OUT_ON(B,2)
#define BPU_OFF OUT_OFF(B,2)

#define BMD_INIT OUT_INIT(B,3)
#define BMD_ON OUT_ON(B,3)
#define BMD_OFF OUT_OFF(B,3)

#define BMU_INIT OUT_INIT(B,4)
#define BMU_ON OUT_ON(B,4)
#define BMU_OFF OUT_OFF(B,4)

#define STEP_FWD_INIT IN_INIT(C,2)
#define STEP_FWD_TEST IN_TEST(C,2)

#define STEP_BCK_INIT IN_INIT(C,5)
#define STEP_BCK_TEST IN_TEST(C,5)

// 100 100 do wst�nych test�w na samych diodach kontrolnych
// 10 10 silniczek nie chwyta
// 7 0 chwyta bo jest rozp�dzony
// silniczek jest na 12-24v, pull-in pulse rate: 900pps
// potrzebna d�ugo�� pulsu co najmniej 20ms dla zasilania 5v
// minimalne pulse delay to 7, dla 6 i mniej wibruje w miejscu
// dla 7 czasem si� zacina bo zmiana kierunku jest niedopracowana
// dla 8 te� si� czasem z rzadka zacina
#define PULSE_DELAY 40
#define STEP_DELAY 100

void pulse_A_PLUS() {
	APU_ON
	AMD_ON
	_delay_ms(PULSE_DELAY);
	APU_OFF
	AMD_OFF
};
void pulse_A_MINUS() {
	APD_ON
	AMU_ON
	_delay_ms(PULSE_DELAY);
	APD_OFF
	AMU_OFF
};
void pulse_B_PLUS() {
	BPU_ON
	BMD_ON
	_delay_ms(PULSE_DELAY);
	BPU_OFF
	BMD_OFF
};
void pulse_B_MINUS() {
	BPD_ON
	BMU_ON
	_delay_ms(PULSE_DELAY);
	BPD_OFF
	BMU_OFF
};

int main(void)
{

	APD_INIT
	APU_INIT
	AMD_INIT
	AMU_INIT
	
	BPD_INIT
	BPU_INIT
	BMD_INIT
	BMU_INIT
	
	STEP_FWD_INIT
	STEP_BCK_INIT
	
	int step=0;
	
	char phase_fwd=0;
	//char phase_bck=0;
	char pressed_fwd=0;
	char pressed_bck=0;
	
	while(1)
	{
		
		pressed_fwd=0;
		pressed_bck=0;
		
		if (STEP_FWD_TEST)
		{
			phase_fwd = (phase_fwd+1)%4;
			pressed_fwd =1;
			step++;
		}
		if (STEP_BCK_TEST)
		{
			//phase_bck = (phase_bck+1)%4;
			phase_fwd = (phase_fwd-1)%4;
			pressed_bck =1;
			step--;
		}
		
		if (pressed_fwd || pressed_bck)
		{
			switch (phase_fwd) {
				case 0:	pulse_B_PLUS(); break;
				case 1:	pulse_A_PLUS(); break;
				case 2:	pulse_B_MINUS(); break;
				case 3: pulse_A_MINUS(); break;
			}
			pressed_fwd=0; pressed_bck=0;
			//phase_bck=(phase_fwd-1)%4;
		}

		//if (pressed_bck)
		//{
		//switch (phase_bck) {
		//case 0:	pulse_A_PLUS(); break;
		//case 1:	pulse_B_PLUS(); break;
		//case 2:	pulse_A_MINUS(); break;
		//case 3: pulse_B_MINUS(); break;
		//}
		//pressed_bck=0;
		//phase_fwd=(phase_bck+1)%4;
		//}
		
		_delay_ms(STEP_DELAY);
		
	}

}

#endif

