
#include "00 informacje o projekcie.h"

#ifdef ITERACJA_12

// sterowanie wej�ciami L297, �eby sprawdzi� jak odwraca sekwencj�
// okazuje si� �e z danego stanu przechodzi w wybrany s�siedni

#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>

// ---- header ports.h, niezale�ny od urz�dzenia, chyba najlepsza opcja

// inicjowanie pojedynczych bit�w jako wej�cie lub wyj�cie
#define OUT_INIT(port,pin) DDR##port |= 1<<pin; PORT##port &= !(1<<pin);
#define OUT_OFF(port,pin) PORT##port &= !(1<<pin);
#define OUT_ON(port,pin) PORT##port |= (1<<pin);
#define IN_INIT(port,pin) DDR##port &= !(1<<pin); PORT##port |= 1<<pin;
#define IN_TEST(port,pin) (!(PIN##port & (1<<pin)))
// inicjowanie ca�ego portu jako wej�cie lub wyj�cie
#define OUT_INIT_PORT(port) DDR##port = 0xFF; PORT##port = 0x00;
#define IN_INIT_PORT(port) DDR##port = 0x00; PORT##port = 0xFF;

// koniec ports.h

int main(void)
{

	OUT_INIT_PORT(D)
	IN_INIT(C,5)
	#define FWD_TEST IN_TEST(C,5)
	IN_INIT(C,2)
	#define BCK_TEST IN_TEST(C,2)
	
	// C0 - clock trigger, C1 - direction toggle
	
	PORTD=0x00000001;

	while(1)
	{
		
		// wys�anie impulsu zerowego
		if (FWD_TEST)
		{
			_delay_ms(500);
			PORTD &= 0x11111110;
			_delay_ms(10);
			PORTD |= 0x00000001;
		}

		// zmiana stanu wyj�cia - nie dzia�a
		if (BCK_TEST)
		{
			PORTD ^= 0x00000010;
			_delay_ms(10);
		}
		
		_delay_ms(100);
		
	}
	
}

#endif
