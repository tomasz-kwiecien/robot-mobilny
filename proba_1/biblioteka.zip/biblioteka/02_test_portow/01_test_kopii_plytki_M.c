
#include "00_konfiguracja_projektu.h"

#ifdef ITERACJA_01

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>

int main(void)
{
	// B0,B2
	DDRB |= 0b00000101;
	PORTB |= 0b11111010;

	// C0,C1,C2,C3,C4,C5
	DDRC |= 0b111111;
	PORTC |= 0b000000;

	// D2,D3,D4,D5,D6,D7
	DDRD |= 0b11111100;
	PORTD |= 0b00000011;
	
	while(1)
	{
		PORTB ^= 0b00000101;
		PORTC ^= 0b111111;
		PORTD ^= 0b11111100;
		_delay_ms(500);
	}
}

#endif