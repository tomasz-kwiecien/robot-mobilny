
// Cel: Przypomnienie obs�ugi port�w w C. Test kopii p�ytki.

//#define ITERACJA_01
//#define ITERACJA_02
//#define ITERACJA_03
#define ITERACJA_04
