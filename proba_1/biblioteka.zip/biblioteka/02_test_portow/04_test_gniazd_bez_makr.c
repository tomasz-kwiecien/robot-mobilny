
#include "00_konfiguracja_projektu.h"

#ifdef ITERACJA_04

// tu te� mi si� dzieje co� dziwnego, ju� nie mam si�y tego poprawia�

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>

// zapalanie diod przyciskami

// konfiguracja port�w:
//
// wej�cie:    D5  D6  D7  B0
// linia IDC:  1   2   4   6
// gniazdo:    3,1 na p�ytce M
//
// wyj�cie:    C5  C2  C1  C0
// linia IDC:  1   2   4   6
// gniazdo:    1,1 na p�ytce M

int main(void)
{
	// B0 wej�cie
	DDRB  &= 0b111111110;
	PORTB |= 0b000000001;

	// D5,D6,D7 wej�cie
	DDRD  &= 0b00011111;
	PORTD |= 0b11100000;

	// C0,C1,C2,C5 wyj�cie
	DDRC  |= 0b111111;
	PORTC |= 0b000000;
	
	while(1)
	{
		// D5 -> C5
		if ( !(PIND & 0b00100000) ) PORTC &= 0b101111; else PORTC |= 0b010000; 
		
		// D6 -> C2
		
		// D7 -> C1
		
		// B0 -> C0
		
		_delay_ms(100);
	}
}

#endif