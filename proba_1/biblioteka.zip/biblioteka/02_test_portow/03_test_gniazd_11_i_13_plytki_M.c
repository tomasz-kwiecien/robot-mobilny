
#include "00_konfiguracja_projektu.h"

#ifdef ITERACJA_03

// tak samo jakie� dziwne b��dy, 
// jak wykomentowuj� niekt�re linie we while to czasem dzia�a

// zapalanie diod przyciskami

// konfiguracja port�w:
//
// wej�cie:    D5  D6  D7  B0  
// linia IDC:  1   2   4   6
// gniazdo:    3,1 na p�ytce M
//
// wyj�cie:    C5  C2  C1  C0
// linia IDC:  1   2   4   6
// gniazdo:    1,1 na p�ytce M

#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>

// ---- header ports.h, niezale�ny od urz�dzenia, chyba najlepsza opcja

// inicjowanie pojedynczych bit�w jako wej�cie lub wyj�cie
#define OUT_INIT(port,pin) {DDR##port |= 1<<pin; PORT##port &= !(1<<pin);}
#define OUT_OFF(port,pin) {PORT##port &= !(1<<pin);}
#define OUT_ON(port,pin) {PORT##port |= (1<<pin);}
#define IN_INIT(port,pin) {DDR##port &= !(1<<pin); PORT##port |= 1<<pin;}
#define IN_TEST(port,pin) (!(PIN##port & (1<<pin)))
// inicjowanie ca�ego portu jako wej�cie lub wyj�cie
#define OUT_INIT_PORT(port) DDR##port = 0xFF; PORT##port = 0x00;
#define IN_INIT_PORT(port) DDR##port = 0x00; PORT##port = 0xFF;

#define OUT_XOR(port,pin) PORT##port ^= !(1<<pin);


int main(void)
{
	IN_INIT_PORT(D);
	IN_INIT_PORT(B);
	OUT_INIT_PORT(C);
	
	while(1)
	{
		if (IN_TEST(D,5)) OUT_ON(C,5) else OUT_OFF(C,5);
		if (IN_TEST(D,6)) OUT_ON(C,2) else OUT_OFF(C,2);
		if (IN_TEST(D,7)) OUT_ON(C,1) else OUT_OFF(C,1);
		if (IN_TEST(B,0)) OUT_ON(C,0) else OUT_OFF(C,0);
		_delay_ms(10);
	}
	
}

#endif
