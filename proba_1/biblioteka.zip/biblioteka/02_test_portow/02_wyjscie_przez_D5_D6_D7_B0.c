
#include "00_konfiguracja_projektu.h"

#ifdef ITERACJA_02

// Cel: Test wyj�cia przez piny D5,D6,D7,B0
// Wykry�em jak�� nie�cis�o�� semantyki. 
// Rezygnuj� z tej opcji bo silnik powinno si� sterowa� 
// jednym przypisaniem do ca�ego portu.

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>

#define OUT_OFF(port,pin) PORT##port &= !(1<<pin);
#define OUT_ON(port,pin) PORT##port |= (1<<pin);

#define OUT_INIT_PORT(port) DDR##port = 0xFF; PORT##port = 0x00;

// kolejno��  D C B A
unsigned char states[4]={
	0b00001010,
	0b00001001,
	0b00000101,
	0b00000110
};

void set_ports(unsigned char state) {
	// zmiana pin�w na kt�re jest wysy�ana sekwencja
	// porty:        D5  D6  D7  B0
	// znaczenie:    D   C   B   A
	if (state & 0b00000001) OUT_ON(B,0) else OUT_OFF(B,0)
	if (state & 0b00000010) OUT_ON(D,7) else OUT_OFF(D,7)
	if (state & 0b00000100) OUT_ON(D,6) else OUT_OFF(D,6)
	if (state & 0b00001000) OUT_ON(D,5) else OUT_OFF(D,5)
	
	// �rodkowe porty, D7 D6, maj� ca�y czas stan niski
	// gdy wykomentuj� jedn� z linii, to te porty prawid�owo zmieniaj� stan
	// wy��czenie Project Properties|Toolchain|AVR/GNU C Compiler|Optimization
	// nic nie zmieni�o
	// Zrezygnowa�em z u�ywania tego gniazda IDC, 
	// bo i tak silnikiem trzeba sterowa� z jednego portu.
}


int main(void)
{
	OUT_INIT_PORT(B)
	OUT_INIT_PORT(D)
	
	int phase=0;
	
	while(1)
	{
		
		//PORTD ^= 0xFF;
		//PORTB ^= 0xFF;
		
  		phase = (phase+1)%4;
  		set_ports(states[phase]);

		_delay_ms(250);
	}
}

#endif
