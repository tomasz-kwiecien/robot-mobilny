
#include "00 informacje o projekcie.h"

#ifdef ITERACJA_07

// test na diod� i przycisk
// okaza�o si� �e mia�em z�y indeks do tablicy lookup

#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>
#include <stdint.h>

// cz�� specyficzna dla atmega8
#define D 0x12
#define C 0x15
#define B 0x18
#define PORT(port) _SFR_IO8(port)
#define DDR(port) _SFR_IO8(port-1)
#define PIN(port) _SFR_IO8(port-2)

#define OUTPUT(port,pin) {DDR(port) |= 1<<pin; PORT(port) &= !(1<<pin);}
#define INPUT(port,pin) {DDR(port) &= !(1<<pin); PORT(port) |= 1<<pin;}
#define SET2(port,pin,bit) if(bit) PORT(port) |= (1<<pin); else PORT(port) &= !(1<<pin);
#define TEST2(port,pin) (!(PIN(port) & (1<<pin)))
#define SET(no,bit) {SET2(lookup[no],lookup[no+1],bit)}
#define TEST(no) TEST2(lookup[no],lookup[no+1])

uint8_t lookup[6] = {D,5,1,C,5,0};

int main(void)
{
	OUTPUT(D,5)
	INPUT(C,5)

	while (1) {
		
		SET(0,0)
		
		if (TEST(3))
		SET(0,1)

		_delay_ms(100);
	}
}

#endif



