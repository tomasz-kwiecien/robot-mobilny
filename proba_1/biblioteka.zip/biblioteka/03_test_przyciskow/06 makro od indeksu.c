
#include "00 informacje o projekcie.h"

#ifdef ITERACJA_06

// prosty test na jedn� diod�
// C:\Program Files\Atmel\Atmel Toolchain\AVR8 GCC\Native\3.4.1061\avr8-gnu-toolchain\avr\include\avr
// io.h -- #elif defined (__AVR_ATmega8A__) #include <avr/iom8a.h>
// iom8a.h sfr_defs.h
// cofa�em si� od b��dnej wersji 6_3_zbyt_zepsutej
// po pierwsze miganie diod�
// okaza�o si� �e mia�em zamienione INPUT z OUTPUT


#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>
#include <stdint.h>

// cz�� specyficzna dla atmega8
#define D 0x12
#define C 0x15
#define B 0x18
#define PORT(port) _SFR_IO8(port)
#define DDR(port) _SFR_IO8(port-1)
#define PIN(port) _SFR_IO8(port-2)

#define OUTPUT(port,pin) {DDR(port) |= 1<<pin; PORT(port) &= !(1<<pin);}
#define INPUT(port,pin) {DDR(port) &= !(1<<pin); PORT(port) |= 1<<pin;}
#define SET2(port,pin,bit) if(bit) PORT(port) |= (1<<pin); else PORT(port) &= !(1<<pin);
#define TEST2(port,pin) (!(PIN(port) & (1<<pin)))
#define SET(no,bit) {SET2(lookup[no],lookup[no+1],bit)}
#define TEST(no) TEST2(lookup[no],lookup[no+1])

uint8_t lookup[3] = {D,5,1};

int main(void)
{
	OUTPUT(D,5)

	uint8_t state=0;
	
	while (1) {
		
		SET(0,state)
		_delay_ms(100);
		state ^= 0x01;
	}
}

#endif
