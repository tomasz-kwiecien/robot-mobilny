
// Cel: Znalezienie optymalnego systemu makr do obs�ugi port�w

//#define ITERACJA_01
//#define ITERACJA_02
//#define ITERACJA_03
//#define ITERACJA_04
//#define ITERACJA_05
//#define ITERACJA_06
//#define ITERACJA_07
//#define ITERACJA_08
//#define ITERACJA_09

