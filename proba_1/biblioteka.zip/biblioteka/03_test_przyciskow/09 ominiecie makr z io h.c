
#include "00 informacje o projekcie.h"

#ifdef ITERACJA_09

// okza�o si� �e "init_ports();" nie by�o wpisane w wersji 5,5-zbyt_zepsutej
// zostawi�em te wersje cz�stkowe bo to ciekawe jak si� szuka b��d�w


#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>
#include <stdint.h>

// cz�� specyficzna dla atmega8
#define D 0x12
#define C 0x15
#define B 0x18
#define PORT(port) _SFR_IO8(port)
#define DDR(port) _SFR_IO8(port-1)
#define PIN(port) _SFR_IO8(port-2)

#define OUTPUT(port,pin) {DDR(port) |= 1<<pin; PORT(port) &= !(1<<pin);}
#define INPUT(port,pin) {DDR(port) &= !(1<<pin); PORT(port) |= 1<<pin;}
#define SET2(port,pin,bit) {if(bit) PORT(port) |= (1<<pin); else PORT(port) &= !(1<<pin);}
#define TEST2(port,pin) (!(PIN(port) & (1<<pin)))
#define SET(no,bit) SET2(lookup[no],lookup[no+1],bit)
#define TEST(no) TEST2(lookup[no],lookup[no+1])

//diody na D5,D6,B0,D7, przyciski na C5,C2,C0,C1
#define PORTS_NO 8
uint8_t lookup[PORTS_NO*3]={
	D,5,1, D,6,1, B,0,1, D,7,1,
	C,5,0, C,2,0, C,0,0, C,1,0
};
#define LED1 0*3
#define LED2 1*3
#define LED3 2*3
#define LED4 3*3
#define SWITCH1 4*3
#define SWITCH2 5*3
#define SWITCH3 6*3
#define SWITCH4 7*3
// powy�ej s� podawane indeksy do tablicy lookup
// zamiast tutaj pisa� te "*3" to nale�a�oby je umie�ci� w makrach TEST i SET

void init_ports() {
	for (uint8_t  i=0; i<=PORTS_NO*3; i+=3)
	if (lookup[i+2])
	OUTPUT(lookup[i],lookup[i+1])
	else
	INPUT(lookup[i],lookup[i+1])
}

int main(void)
{
	init_ports();

	while (1) {
		
		SET(LED1,0)
		SET(LED2,0)
		SET(LED3,0)
		SET(LED4,0)
		
		if (TEST(SWITCH1))
		SET(LED1,1)
		if (TEST(SWITCH2))
		SET(LED2,1)
		if (TEST(SWITCH3))
		SET(LED3,1)
		if (TEST(SWITCH4))
		SET(LED4,1)

		_delay_ms(100);
	}
}

#endif


