
#include "00 informacje o projekcie.h"

#ifdef ITERACJA_02

// if (!(PINC & (1<<5))) PORTD ^= (1<<5);
// 4 diody i przyciski
// mia�em b��d w po��czeniach na p�ytce, odczytywane s� wiersze
// wiersze s� podpi�te do baz tranzystor�w, mo�na to kiedy� przerobi�
// operacje na sta�ych s� optymalizowane przez preprocesor
// 152 bajty w obu wariantach

// diody na D5,D6,B0,D7, przyciski na C5,C2,C0,C1
// 152 bajty

#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>

int main(void)
{
	
	//przyciski
	DDRC &=  0b011000;
	PORTC |= 0b100111;  // internal pull-up

	//diody
	DDRD |=	 0b11110000;
	PORTD &= 0b00001111;
	
	DDRB |=  0b00000001;
	PORTB &= 0b11111110;
	
	while(1)
	{

		PORTB = 0x00;
		PORTD = 0x00;
		
		if (!(PINC & (1<<5)))
		PORTD ^= (1<<5);
		if (!(PINC & (1<<2)))
		PORTD ^= (1<<6);
		if (!(PINC & (1<<0)))
		PORTB ^= (1<<0);
		if (!(PINC & (1<<1)))
		PORTD ^= (1<<7);
		
		// C5,C2,C0,C1 przyciski
		// D5,D6,B0,D7 diody
		
		_delay_ms(10);
		
	}
}

#endif
