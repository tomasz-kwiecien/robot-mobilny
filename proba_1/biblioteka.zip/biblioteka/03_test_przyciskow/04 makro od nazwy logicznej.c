
#include "00 informacje o projekcie.h"

#ifdef ITERACJA_04

// if (SWITCH_1_TEST) DIODE_1_ON
// odwo�anie do port�w przez nazwy makr
// trzeba du�o definiowa�, poprawia�, najlepiej realizowa� to obiektowo
//
// 160 bajt�w

// wyb�r portu poprzez nazw� makra
// diody na D5,D6,B0,D7, przyciski na C5,C2,C0,C1
// 160 bajt�w

#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>

int main(void)
{
	
	#define INIT_OUT(port,pin) DDR##port |= 1<<pin; PORT##port &= !(1<<pin);
	#define OUT_OFF(port,pin) PORT##port &= !(1<<pin);
	#define OUT_ON(port,pin) PORT##port |= (1<<pin);
	
	#define INIT_IN(port,pin) DDR##port &= !(1<<pin); PORT##port |= 1<<pin;
	#define IN_TEST_LOW(port,pin) (!(PIN##port & (1<<pin)))
	
	// diody D5,D6,B0,D7, przyciski na C5,C2,C0,C1
	
	INIT_OUT(D,5)
	#define DIODE_1_ON OUT_ON(D,5)
	#define DIODE_1_OFF OUT_OFF(D,5)
	
	INIT_OUT(D,6)
	#define DIODE_2_ON OUT_ON(D,6)
	#define DIODE_2_OFF OUT_OFF(D,6)
	
	INIT_OUT(B,0)
	#define DIODE_3_ON OUT_ON(B,0)
	#define DIODE_3_OFF OUT_OFF(B,0)
	
	INIT_OUT(D,7)
	#define DIODE_4_ON OUT_ON(D,7)
	#define DIODE_4_OFF OUT_OFF(D,7)

	INIT_IN(C,5)
	#define SWITCH_1_TEST IN_TEST_LOW(C,5)
	
	INIT_IN(C,2)
	#define SWITCH_2_TEST IN_TEST_LOW(C,2)
	
	INIT_IN(C,0)
	#define SWITCH_3_TEST IN_TEST_LOW(C,0)
	
	INIT_IN(C,1)
	#define SWITCH_4_TEST IN_TEST_LOW(C,1)
	
	// prze��czanie diod przyciskami
	while (1) {
		
		DIODE_1_OFF
		DIODE_2_OFF
		DIODE_3_OFF
		DIODE_4_OFF
		
		if (SWITCH_1_TEST)
		DIODE_1_ON
		if (SWITCH_2_TEST)
		DIODE_2_ON
		if (SWITCH_3_TEST)
		DIODE_3_ON
		if (SWITCH_4_TEST)
		DIODE_4_ON
		
		_delay_ms(100);
	}
}

#endif
