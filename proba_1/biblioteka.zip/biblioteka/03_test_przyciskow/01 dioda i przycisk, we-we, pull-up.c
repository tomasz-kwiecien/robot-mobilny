
#include "00 informacje o projekcie.h"

#ifdef ITERACJA_01

// if ( PINC & 0x01 ) PORTD &= 0b00000000;
// 1 dioda i przycisk
// jak wpi��em gnd do avcc to procesor si� zacz�� grza�
// zrezygnowa�em z nalepek, wa�niejsza jest dla mnie kontrola temperatury
// mia�em wpisany inny uC w poleceniu  C:\WinAVR\bin\avrdude.exe
// -e -P usb -c USBasp -p m8 -e -U flash:w:$(ProjectDir)Debug\$(ItemFileName).hex:a
// pomyli�em w ustawieniach projektu 88a z 8a
// gdy port dzia�a jako wej�cie to wpisanie na niego jedynki te� zmienia napi�cie
// tylko w mniejszym stopniu - to jest internal pullup
// 102 bajty

// D5, dioda, rezystor 100om, masa
// C5, switch, masa
// 102 bajty

#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>

int main(void)
{
	
	DDRC = 0b000000;  // C5 jako wej�cie
	PORTC = 0b100000;  // internal pull-up
	DDRD = 0b00100000;
	PORTD = 0b00000000;
	
	while(1)
	{
		if ( PINC & 0b100000 ) // bit 0 - przycisk zwolniony
		PORTD &= 0b00000000; // gaszenie
		else
		PORTD |= 0b00100000; // �wiecenie

		_delay_ms(100);
	}
}

#endif
