
#include "00 informacje o projekcie.h"

#ifdef ITERACJA_05

// odwo�anie do port�w przez parametry makr
// http://support.atmel.no/knowledgebase/avrstudiohelp/mergedprojects/avrasm/html/AVR_Assembler_2_Preprocessor.htm#Concatenation
// podczas rozwijania makr nie mo�na skatenowa� terminala z nieterminalem
// // to si� kompiluje:
// #define PORT(l) PORT##l
// PORT(D)=0;
// #define OUT_1_PORT D
// #define TEST1(i) PORT(OUT_##i##_PORT)=0;
// #define OUT_2_PORT PORTD
// #define TEST2(i) OUT_##i##_PORT=0;
// TEST2(2)
// // to si� nie kompiluje:
// PORT(OUT_1_PORT) // rozwinie si� do PORTOUT_1_PORT
// TEST1(1) // rozwinie si� do PORTOUT_1_PORT
// // tak si� te� nie da:
// #define OUT(i,port,num) #define OUT_#i_PORT PORT#port
//	 					   #define OUT_#i_DDR DRD#port
//	 					   #define OUT_#i_NUM num
// OUT(1,D,5)
// rozdzielenie INIT na INIT PORT i INIT DDR nie zmienia d�ugo�ci kodu
// 160 bajt�w

// wyb�r portu poprzez parametr makra
// atmega8a, diody na D5,D6,B0,D7, przyciski na C5,C2,C0,C1

#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>

int main(void)
{
	// header
	
	#define OUT_INIT(i) OUT_##i##_DDR |= (1<<OUT_##i##_NUM); OUT_##i##_PORT &= !(1<<OUT_##i##_NUM);
	#define OUT_ON(i) OUT_##i##_PORT |= (1<<OUT_##i##_NUM);
	#define OUT_OFF(i) OUT_##i##_PORT  &= !(1<<OUT_##i##_NUM);

	#define IN_INIT(i) IN_##i##_DDR &= !(1<<IN_##i##_NUM); IN_##i##_PORT |= (1<<IN_##i##_NUM);
	#define IN_TEST(i) (!(IN_##i##_PIN & (1<<IN_##i##_NUM)))
	
	// makra konfiguracyjne
	
	#define OUT_1_PORT PORTD
	#define OUT_1_DDR DDRD
	#define OUT_1_NUM 5
	#define OUT_2_PORT PORTD
	#define OUT_2_DDR DDRD
	#define OUT_2_NUM 6
	#define OUT_3_PORT PORTB
	#define OUT_3_DDR DDRB
	#define OUT_3_NUM 0
	#define OUT_4_PORT PORTD
	#define OUT_4_DDR DDRD
	#define OUT_4_NUM 7
	
	#define IN_1_PORT PORTC
	#define IN_1_DDR DDRC
	#define IN_1_PIN PINC
	#define IN_1_NUM 5
	#define IN_2_PORT PORTC
	#define IN_2_DDR DDRC
	#define IN_2_PIN PINC
	#define IN_2_NUM 2
	#define IN_3_PORT PORTC
	#define IN_3_DDR DDRC
	#define IN_3_PIN PINC
	#define IN_3_NUM 0
	#define IN_4_PORT PORTC
	#define IN_4_DDR DDRC
	#define IN_4_PIN PINC
	#define IN_4_NUM 1
	
	// kod
	
	OUT_INIT(1)
	OUT_INIT(2)
	OUT_INIT(4)
	OUT_INIT(3)

	IN_INIT(1)
	IN_INIT(2)
	IN_INIT(3)
	IN_INIT(4)

	while (1) {
		
		OUT_OFF(1)
		OUT_OFF(2)
		OUT_OFF(3)
		OUT_OFF(4)
		
		if (IN_TEST(1))
		OUT_ON(1)
		if (IN_TEST(2))
		OUT_ON(2)
		if (IN_TEST(3))
		OUT_ON(3)
		if (IN_TEST(4))
		OUT_ON(4)

		_delay_ms(100);
	}
}

#endif
