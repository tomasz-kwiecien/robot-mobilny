
#include "00 informacje o projekcie.h"

#ifdef ITERACJA_03

// if (IN_LOW(C,5)) OUT_ON(D,5)
// odwo�ania do port�w poprzez adres jako parametr makra
// nieprzydatne, chodzi mi o mo�liwo�� zmiany konfiguracji bez zmieniania g��wnego kodu
// ci�gi przypisa� jednobitowych s� optymalizowane przez kompilator
// 154 bajty

// odwo�ania do port�w poprzez adres jako parametr makra
// diody na D5,D6,B0,D7, przyciski na C5,C2,C0,C1
// 154 bajty

#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>

int main(void)
{
	
	#define INIT_OUT(port,pin) DDR##port |= 1<<pin; PORT##port &= !(1<<pin);
	#define INIT_IN(port,pin) DDR##port &= !(1<<pin); PORT##port |= 1<<pin;
	
	INIT_OUT(D,5)
	INIT_OUT(D,6)
	INIT_OUT(B,0)
	INIT_OUT(D,7)
	
	INIT_IN(C,5)
	INIT_IN(C,2)
	INIT_IN(C,0)
	INIT_IN(C,1)

	while(1)
	{

		#define IN_LOW(port,pin) (!(PIN##port & (1<<pin)))
		#define OUT_TOGGLE(port,pin) PORT##port ^= (1<<pin);
		#define OUT_OFF(port,pin) PORT##port &= !(1<<pin);
		#define OUT_ON(port,pin) PORT##port |= (1<<pin);
		
		OUT_OFF(D,5)
		OUT_OFF(D,6)
		OUT_OFF(B,0)
		OUT_OFF(D,7)
		
		// guziki i diody od lewej do prawej
		if (IN_LOW(C,5))
		OUT_ON(D,5)
		if (IN_LOW(C,2))
		OUT_ON(D,6)
		if (IN_LOW(C,0))
		OUT_ON(B,0)
		if (IN_LOW(C,1))
		OUT_ON(D,7)
		
		_delay_ms(10);
		
	}
}

#endif
