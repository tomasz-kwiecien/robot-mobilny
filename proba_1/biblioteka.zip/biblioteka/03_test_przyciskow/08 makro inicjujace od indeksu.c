
#include "00 informacje o projekcie.h"

#ifdef ITERACJA_08

// wklejona automatyczna inicjalizacja
// okaza�o si� �e init_ports mia�o �le indeksy


#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>
#include <stdint.h>

// cz�� specyficzna dla atmega8
#define D 0x12
#define C 0x15
#define B 0x18
#define PORT(port) _SFR_IO8(port)
#define DDR(port) _SFR_IO8(port-1)
#define PIN(port) _SFR_IO8(port-2)

#define OUTPUT(port,pin) {DDR(port) |= 1<<pin; PORT(port) &= !(1<<pin);}
#define INPUT(port,pin) {DDR(port) &= !(1<<pin); PORT(port) |= 1<<pin;}
#define SET2(port,pin,bit) {if(bit) PORT(port) |= (1<<pin); else PORT(port) &= !(1<<pin);}
#define TEST2(port,pin) (!(PIN(port) & (1<<pin)))
#define SET(no,bit) SET2(lookup[no],lookup[no+1],bit)
#define TEST(no) TEST2(lookup[no],lookup[no+1])

#define PORTS_NO 2
uint8_t lookup[PORTS_NO*3] = {D,5,1,C,5,0};  // port,pin,type
#define LED1 0
#define SWITCH1 3

void init_ports() {
	for (uint8_t  i=0; i<=PORTS_NO*3; i+=3)
	if (lookup[i+2])
	OUTPUT(lookup[i],lookup[i+1])
	else
	INPUT(lookup[i],lookup[i+1])
}

int main(void)
{
	init_ports();

	while (1) {
		
		SET(LED1,0)
		
		if (TEST(SWITCH1))
		SET(LED1,1)

		_delay_ms(100);
	}
}

#endif

