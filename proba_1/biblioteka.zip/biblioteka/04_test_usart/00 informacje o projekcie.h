
// Cel: Przypomnienie obs�ugi usart

//#define ITERACJA_01
#define ITERACJA_02