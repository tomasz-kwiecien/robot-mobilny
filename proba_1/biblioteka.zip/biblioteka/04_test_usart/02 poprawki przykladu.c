
#include "00 informacje o projekcie.h"

#ifdef ITERACJA_02

// wyci�te z przyk�adu i drobne poprawki

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>

#include <inttypes.h>

void USARTInit(uint16_t ubrr_value)
{
	UBRRL = ubrr_value;
	UBRRH = (ubrr_value>>8);
	UCSRC=(1<<URSEL)|(3<<UCSZ0);
	UCSRB=(1<<RXEN)|(1<<TXEN);
}


void USARTSendChar(char data)
{
	while(!(UCSRA & (1<<UDRE)));
	UDR=data;
}

char USARTReceiveChar()
{
	if ((UCSRA & (1<<RXC)))
	return UDR;
	else
	return 0;
}

void USARTSendString(char s[])
{
	int i =0;
	while (s[i] != 0x00)
	{
		USARTSendChar(s[i]);
		i++;
	}
}

int main(void)
{
	DDRC = 0b100110;  // C0 jako wej�cie
	PORTC = 0b000001;  // internal pull-up
	
	USARTInit(51);
	
	
	while(1)
	{
		if (USARTReceiveChar()!=0)
		{
			PORTC ^= 0b100000;
			USARTSendString("PC\r");
		}
		
		if ( PINC & 0x01 ) // bit 0 - przycisk zwolniony
		PORTC &= 0b111001; // gaszenie
		else
		{
			PORTC |= 0b000110; // �wiecenie
			USARTSendString("uC\r");
		}
		
		_delay_ms(100);
		
	}
}

#endif
